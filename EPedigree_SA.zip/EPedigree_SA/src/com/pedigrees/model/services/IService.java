/**
 * 
 */
package com.pedigrees.model.services;

/**
 * @author Ish
 * 
 * Marker interface allows all classes in tiers
 *
 */
public interface IService {

}
