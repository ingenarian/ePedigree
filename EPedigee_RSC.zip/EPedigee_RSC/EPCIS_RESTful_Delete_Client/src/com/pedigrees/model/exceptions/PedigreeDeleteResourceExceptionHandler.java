/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.pedigrees.model.exceptions;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;
import javax.ws.rs.ext.Provider;
import javax.ws.rs.ext.ExceptionMapper;
/**
 *
 * @author Ish
 * The PedigreeDeleteResourceExceptionHandler class
 * implements the ExceptionMapper for a PedigreeDeleteResourceException type
 */
@Provider
public class PedigreeDeleteResourceExceptionHandler implements ExceptionMapper<PedigreeDeleteResourceException>{

    @Override
    public Response toResponse(PedigreeDeleteResourceException exception) {
        return Response.status(Status.SERVICE_UNAVAILABLE).entity(exception.getMessage()).build();
    }// end of toResponse Method    
    
}// end of PedigreeDeleteResourceExceptionHandler Class
