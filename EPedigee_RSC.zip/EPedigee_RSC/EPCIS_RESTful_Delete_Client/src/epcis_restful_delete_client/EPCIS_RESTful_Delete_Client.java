/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package epcis_restful_delete_client;

import com.pedigrees.model.exceptions.PedigreeDeleteResourceException;
import com.sun.jersey.api.client.Client;
import com.sun.jersey.api.client.WebResource;
import com.sun.jersey.api.client.config.ClientConfig;
import com.sun.jersey.api.client.config.DefaultClientConfig;
import com.sun.jersey.api.client.ClientResponse;
import com.sun.jersey.api.client.filter.HTTPBasicAuthFilter;
import java.net.URI;
import javax.ws.rs.core.UriBuilder;

/**
 *
 * @author Ish
 * TheEPCIS RESTful Client implements
 * the Jersey-style RESTful web services
 * for deleting a resource in a database.
 * Should return HTTP code 204 - "no content"
 * 
 */
public class EPCIS_RESTful_Delete_Client {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws PedigreeDeleteResourceException{
        
        
        //Client set-up
        ClientConfig config = new DefaultClientConfig();
        Client client = Client.create(config);
        HTTPBasicAuthFilter authFilter = new HTTPBasicAuthFilter("Admin","Lat33f");
        client.addFilter(authFilter);
        WebResource service = client.resource(getBaseURI());
       
      //Resource type -"No Content" - Pedigree and CRUD - "DELETE" (DELETE)
        try{
            
            //Test the Wrong Method Request - Produces 405 - Method Not Allowed
            ClientResponse response4a = service.path("rest").path("oldpedigree").get(ClientResponse.class);
            System.out.println(response4a);
            System.out.println();
       
           //Test without a Media Type and Method Request - Produces 200 Status code - OK
           ClientResponse response4b = service.path("rest").path("oldpedigree").delete(ClientResponse.class);
           System.out.println(response4b);
            
        }catch (Exception excp4){
            String pedigree = "Can not delete pedigree; ";
            pedigree = pedigree +  "service provider not available!";
            throw new PedigreeDeleteResourceException(pedigree, excp4);
            
        }// end of try/catch PedigreeDeleteResourceException block
    }// end of Main Method
    
     //Build resource type - "XML - Pedigree"
    private static URI getBaseURI() {
        return UriBuilder.fromUri("https://localhost:8181/EPCIS").build();
    }// end getBaseURI Method
}// end of EPCIS_RESTful_Delete_Client Class
