/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.pedigrees.model.exceptions;
import java.io.Serializable;

/**
 *
 * @author Ish
 * 
 * PedigreeCreateResourceException class is a custom checked exception.
 * It is designed for try/catch operations for the JAX-RS PedgireeCreateResource.
 */
public class PedigreeCreateResourceException extends Exception implements Serializable{
    
    public PedigreeCreateResourceException(){
        super();
    }// end of no argument PedigreeCreateResourceException Constructor
    
    public PedigreeCreateResourceException(String msg){
        super(msg);
    }// end of one argument PedigreeCreateResourceException Constructor
    
    public PedigreeCreateResourceException(String msg, Exception e){
        super(msg, e);
    }// end of two argument PedigreeCreateResourceException Constructor
    
}// end of PedigreeCreateResourceException Class
