/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.pedigrees.model.exceptions;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;
import javax.ws.rs.ext.Provider;
import javax.ws.rs.ext.ExceptionMapper;
/**
 *
 * @author Ish
 * 
 * The PedigreeCreateResourceExceptionHandler class
 * implements the ExceptionMapper for a PedigreeCreateResourceException type
 */
@Provider
public class PedigreeCreateResourceExceptionHandler implements ExceptionMapper<PedigreeCreateResourceException>{

    @Override
    public Response toResponse(PedigreeCreateResourceException exception) {
        return Response.status(Status.SERVICE_UNAVAILABLE).entity(exception.getMessage()).build();
    }// end of toResponse Method
    
}// end of PedigreeCreateResourceExceptionHandler Class
