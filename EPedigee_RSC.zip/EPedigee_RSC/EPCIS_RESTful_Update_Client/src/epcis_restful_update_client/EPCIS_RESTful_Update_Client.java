/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package epcis_restful_update_client;

import com.pedigrees.model.exceptions.PedigreeUpdateResourceException;
import com.sun.jersey.api.client.Client;
import com.sun.jersey.api.client.WebResource;
import com.sun.jersey.api.client.config.ClientConfig;
import com.sun.jersey.api.client.config.DefaultClientConfig;
import com.sun.jersey.api.client.ClientResponse;
import com.sun.jersey.api.client.filter.HTTPBasicAuthFilter;
import java.net.URI;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.UriBuilder;

/**
 *
 * @author Ish
 * TheEPCIS RESTful Client implements
 * the Jersey-style RESTful web services
 * for updating a resource in a database.
 */
public class EPCIS_RESTful_Update_Client {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws PedigreeUpdateResourceException{
        
        //Client set-up
        ClientConfig config = new DefaultClientConfig();
        Client client = Client.create(config);
        HTTPBasicAuthFilter authFilter = new HTTPBasicAuthFilter("Admin","Lat33f");
        client.addFilter(authFilter);
        WebResource service = client.resource(getBaseURI());
        
         //Resource type - XML - Pedigree and CRUD - "UPDATE" (PUT)
        try{
            
            //Test the Wrong Method Request - Produces 405 - Method Not Allowed
            ClientResponse response3a = service.path("rest").path("currentpedigree").accept(MediaType.APPLICATION_XML).delete(ClientResponse.class);
            System.out.println(response3a);
            System.out.println();
        
           //Test the Correct Media Type and Method Request - Produces 200 Status code - OK
           ClientResponse response3b = service.path("rest").path("currentpedigree").accept(MediaType.APPLICATION_XML).put(ClientResponse.class);
           System.out.println(response3b);
        }catch (Exception excp3){
            String pedigree = "Can not update pedigree; ";
            pedigree = pedigree +  "service provider not available!";
            throw new PedigreeUpdateResourceException(pedigree, excp3);
            
        }// end of try/catch PedigreeUpdateResourceException block
        
        
    }// end of Main Method
    
    //Build resource type - "XML - Pedigree"
    private static URI getBaseURI() {
        return UriBuilder.fromUri("https://localhost:8181/EPCIS").build();
    }// end getBaseURI Method
    
}// end of EPCIS_RESTful_Update_Client Class
