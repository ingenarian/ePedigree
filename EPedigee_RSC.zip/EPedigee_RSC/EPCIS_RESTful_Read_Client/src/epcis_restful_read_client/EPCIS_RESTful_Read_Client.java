/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package epcis_restful_read_client;
import com.pedigrees.model.exceptions.PedigreeReadResourceException;
import com.sun.jersey.api.client.Client;
import com.sun.jersey.api.client.WebResource;
import com.sun.jersey.api.client.config.ClientConfig;
import com.sun.jersey.api.client.config.DefaultClientConfig;
import com.sun.jersey.api.client.ClientResponse;
import com.sun.jersey.api.client.filter.HTTPBasicAuthFilter;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.UriBuilder;
import java.net.URI;
/**
 *
 * @author Ish
 * 
 * TheEPCIS RESTful Client implements
 * the Jersey-style RESTful web services
 * for reading a resource in a database.
 */
public class EPCIS_RESTful_Read_Client {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws PedigreeReadResourceException{
        
        //Client set-up
        ClientConfig config = new DefaultClientConfig();
        Client client = Client.create(config);
        HTTPBasicAuthFilter authFilter = new HTTPBasicAuthFilter("Admin","Lat33f");
        client.addFilter(authFilter);
        WebResource service = client.resource(getBaseURI());
        
        //Resource type - XML - Pedigree and CRUD - "READ" (GET)
        try{
            
            //Test the Wrong Method Request - Produces 405 - Method Not Allowed
            ClientResponse response2a = service.path("rest").path("selectivepedigree/1.xml").accept(MediaType.APPLICATION_XML_TYPE).post(ClientResponse.class);
            System.out.println(response2a);
            System.out.println();
        
           //Test the Correct Media Type and Method Request - Produces 200 Status code - OK
           ClientResponse response2b = service.path("rest").path("selectivepedigree/1.xml").accept(MediaType.APPLICATION_XML_TYPE).get(ClientResponse.class);
           System.out.println(response2b);
        }catch (Exception excp2){
            String pedigree = "Can not read pedigree; ";
            pedigree = pedigree +  "service provider not available!";
            throw new PedigreeReadResourceException(pedigree, excp2);
        }// end of try/catch PedigreeReadResourceException block
        
    }// end of Main Method
    
     //Build resource type - "XML - Pedigree"
    private static URI getBaseURI() {
        return UriBuilder.fromUri("https://localhost:8181/EPCIS").build();
    }// end getBaseURI Method
    
}// end of EPCIS_RESTful_Read_Client
