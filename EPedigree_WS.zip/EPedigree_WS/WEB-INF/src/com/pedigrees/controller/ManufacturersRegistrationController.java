/**
 * 
 */
package com.pedigrees.controller;
import com.pedigrees.model.manager.ManufacturerRegistrationManager;
import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.*;

/**
 * @author Ishmael Thomas
 *
 * Production Model: ManufacturersRegistrationController (Java Servlet)
 * 
 * Captures user input from the manufacturer's registration form
 * using the the HttpServletRequest getParameters method and holds them in String variables.
 *
 * User's input is tested with a control marker (integer variable called "count") and with conditional
 * logic is used to validated the user's input held in the String variables.
 * 
 * If the conditions fail, then the error message servlet is called and the HttpServletResponse methods
 * send a form containing a failed registration message.
 * 
 * If the conditions succeed, then the success message serlvet is called and the HttpServletResponse methods
 * send a form containing a success registration message.
 *
 * 
 */
public class ManufacturersRegistrationController extends HttpServlet {

	/**
	 * 
	 */
	private static final long serialVersionUID = 3113480056436510146L;
	

	
	//HttPServlet POST method called into action from the user's html form
	public void doPost(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException{
		
			
		//Executing and testing HttpServletRequest method
		String mName = req.getParameter("manufacturersName");
		System.out.println(mName);
		
		
		//Executing and testing HttpServletRequest method
		String mUName = req.getParameter("manufacturersUsersName");
		System.out.println(mUName);
		
		//Executing and testing HttpServletRequest method
		String mPassword = req.getParameter("manufacturersPassword");
		System.out.println(mPassword);
		
		//Executing and testing HttpServletRequest method
		String mSignature = req.getParameter("manufacturersSignature");
		System.out.println(mSignature);
		
		
		//Process and validation status
		String status;
		
				
		//Process and validate user's input with the ManufacturerRegistrationManager
		ManufacturerRegistrationManager manufacturerRegistrationManager = new ManufacturerRegistrationManager();
		status = manufacturerRegistrationManager.validate(mName, mUName, mPassword, mSignature);
		System.out.println(status);
		
		//Evaluate status and forward the process results
		if(status == "true"){
						
			getServletContext().getRequestDispatcher("/jsp/mfgRegistrationGood.jsp").forward(req, res);
		
		}else if (status == "false"){
		
			getServletContext().getRequestDispatcher("/jsp/mfgRegistrationError.jsp").forward(req, res);
		} // end of Evaluating and forwarding
		
	}// end of doPOST
	
}// end of ManufacturersRegistrationController
