/**
 * 
 */
package com.pedigrees.controller;
import com.pedigrees.model.manager.PedigreeLoginManager;
import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
/**
 * @author Ishmael Thomas
 * 
 * Production Model: PedigreeLoginController (Java Servlet)
 * 
 * Captures user login and password input from the electronic pedigree login registration form
 * using the the HttpServletRequest getParameters method and holds them in String variables.
 *
 * User's input is test with a control marker (integer variable called "count") and with conditional
 * logic is used to validated the user's input held in the String variables.
 * 
 * If the conditions fail, then the error message servlet is called and the HttpServletResponse methods
 * send a form containing a failed login message.
 * 
 * If the conditions succeed, then the success message servlet is called and the HttpServletResponse methods
 * send a form containing a success login message.
 *
 */
public class PedigreeLoginController extends HttpServlet {

	/**
	 * 
	 */
	private static final long serialVersionUID = 7330628643073879723L;

	public void doPost(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException{
				
		
		//Executing and testing HttpServletRequest method
		String usersLogin = req.getParameter("usersLoginName");
		
				
		//Executing and testing HttpServletRequest method
		String usersPassword = req.getParameter("usersLoginPassword");
		
		//Process, validation, and authentication status
		String status;
		
		//Process,validate, and authenticate login properties with the PedigreeLoginManager
		PedigreeLoginManager pedigreeLoginManager = new PedigreeLoginManager();
		status = pedigreeLoginManager.validate(usersLogin, usersPassword);
		
        System.out.println(status);
		
		//Evaluate status and forward the process results
		if(status == "true"){
			
			getServletContext().getRequestDispatcher("/jsp/mfgLoginGood.jsp").forward(req, res);
		
		}else if (status == "false"){
		
			getServletContext().getRequestDispatcher("/jsp/mfgLoginError.jsp").forward(req, res);
		} // end of Evaluating and forwarding
		
	}// end of doPOST

}// end of PedigreeLoginController Class
