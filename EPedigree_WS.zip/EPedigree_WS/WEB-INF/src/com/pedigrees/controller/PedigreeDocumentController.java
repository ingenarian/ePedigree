/**
 * 
 */
package com.pedigrees.controller;
import com.pedigrees.model.manager.PedigreeDocumentManager;
import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.*;



/**
 * @author Ishmael Thomas
 *
 * Production Model: PedigreeDocumentController (Java Servlet)
 * 
 * Captures user input from the initial pedigree form using the 
 * HttpServletRequest getParameters method and holds them in String variables.
 *
 * User's input is test with a control marker (integer variable called "count") and with conditional
 * logic is used to validated the user's input held in the String variables.
 * 
 * If the conditions fail, then the user is directed to an  error page.
 * 
 * If the conditions succeed, then the user is directed to a success page.
 *
 * 
 */
public class PedigreeDocumentController extends HttpServlet{

	/**
	 * 
	 */
	private static final long serialVersionUID = 4373774581604524485L;
	
	//HttPServlet POST method called into action from the user's html form
	public void doPost(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException{
		
				
		//Executing and testing HttpServletRequest method
		String serial = req.getParameter("serialNumber");
		
		
		//Executing and testing HttpServletRequest method
		String mfg = req.getParameter("manufacturer");
		
		
		//Executing and testing HttpServletRequest method
		String drug = req.getParameter("drugName");
		
		
		//Executing and testing HttpServletRequest method
		String item = req.getParameter("itemInfo");
		
		
		//Executing and testing HttpServletRequest method
		String product = req.getParameter("productInfo");
	
		
		//Executing and testing HttpServletRequest method
		String lot = req.getParameter("lot");
		
		//Executing and testing HttpServletRequest method
		String quantity = req.getParameter("quantity");
		
		//Process and validation status
		String status;
		
		//Process and validate user's input with the PedigreeDocumentManager
		PedigreeDocumentManager pedigreeDocumentManager = new PedigreeDocumentManager();
		status = pedigreeDocumentManager.validate(serial, mfg, drug, item, product, lot, quantity);
		System.out.println(status);
		
		//Evaluate status and forward the process results
		if(status == "true"){
			
			getServletContext().getRequestDispatcher("/jsp/pedigreeDocCreationGood.jsp").forward(req, res);
		
		}else if (status == "false"){
		
			getServletContext().getRequestDispatcher("/jsp/pedigreeDocCreationError.jsp").forward(req, res);
		} // end of Evaluating and forwarding		
		
	}// end of doPOST


} // end of PedigreeDocumentController Class
