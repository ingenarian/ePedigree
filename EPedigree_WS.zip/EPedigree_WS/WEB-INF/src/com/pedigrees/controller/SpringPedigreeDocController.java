/**
 * 
 */
package com.pedigrees.controller;

/**
 * @author Ishmael Thomas
 * An annotated-controller following the Spring MVC design
 * pattern for handling web requests, creating models, and
 * delegating the rendered responses for creating 
 * pedigree documents.
 */
public class SpringPedigreeDocController {

}// end of SpringPedigreeDocController Class
