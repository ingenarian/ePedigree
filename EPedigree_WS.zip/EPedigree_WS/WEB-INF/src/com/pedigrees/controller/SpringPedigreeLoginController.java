/**
 * 
 */
package com.pedigrees.controller;
import javax.validation.Valid;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.pedigrees.model.domain.Manufacturer;
import com.pedigrees.model.manager.SpringPedigreeLoginManager;
/**
 * @author Ishmael Thomas
 * An annotated-controller following the Spring MVC design
 * pattern for handling web requests, creating models, and
 * delegating the rendered responses for the pedigree logins. 
 * 
 */
//Designated POJO as a Spring MVC Controller
@Controller
public class SpringPedigreeLoginController {
	//Request for url path "/ePedigreeAppLogin"	
	@RequestMapping(value = "/ePedigreeAppLogin", method = RequestMethod.GET)
	public String springEPedigreeAppLogin(Model model){
		model.addAttribute("manufacturer", new Manufacturer());
		
		return "ePedigreeAppLogin";
	}// end of springCustomerLogin for RequestMethod.GET
	
	
	//Request for url path "/ePedigreeAppLogin"	
	@RequestMapping(value = "/ePedigreeAppLogin", method = RequestMethod.POST)
	public String springEPedigreeAppLogin(@ModelAttribute("manufacturer") @Valid Manufacturer manufacturer, BindingResult result){
		if(result.hasErrors()){
			
			return "ePedigreeAppLogin";
		} else {
			
			String status = new SpringPedigreeLoginManager().process(manufacturer);
			if(status == "false"){
				
				return "ePedigreeAppLogin";
				
			} else {
				
				return "ePedigreeDocCreator";
			}// end of process condition
		}// end of JSR-303 validate condition
		
	}// end of springCustomerLogin for RequestMethod.POST 
	
		
}// end of SpringPedigreeLoginController Class
