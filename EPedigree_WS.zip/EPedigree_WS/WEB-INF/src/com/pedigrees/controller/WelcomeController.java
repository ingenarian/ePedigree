/**
 * 
 */
package com.pedigrees.controller;
import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
/**
 * @author Ishmael Thomas
 * 
 * The Welcome Controller accepts http request parameters
 * from the Welcome http form and processes those request
 * in the doPost method. From there, logic in the doPost
 * method evaluates the http request parameters and returns
 * the appropriate http response.
 *
 */
public class WelcomeController extends HttpServlet{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
public void doPost(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException{
		
		String number = req.getParameter("welcomeRequest");

        System.out.println(number);
		
		//Evaluate status and forward the process results
		if(number.equalsIgnoreCase("1")){
		
			getServletContext().getRequestDispatcher("/ePedigreeDocCreator.html").forward(req, res);
		
		}else {
			
			getServletContext().getRequestDispatcher("/ePedigreeMfgReg.html").forward(req, res);
		} // end of Evaluating and forwarding
				
	}// end of doPOST

}// end of WelcomeController Class
