package com.pedigrees.model.exceptions;

/**
 * @author Ishmael Thomas
 * Throws a services  load exception if there are issues between the service factory, use case managers, and
 * IService.
 */
@SuppressWarnings("serial")
public class ServiceLoadException extends Exception {
	
	public ServiceLoadException(final String svcMessage, final Throwable svcNestedException)
    {
        super(svcMessage, svcNestedException);
    } // end of ServiceLoadException Method

} // end of ServiceLoadException Class