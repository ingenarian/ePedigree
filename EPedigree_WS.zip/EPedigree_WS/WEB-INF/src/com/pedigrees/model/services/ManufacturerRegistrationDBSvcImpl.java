/**
 * 
 */
package com.pedigrees.model.services;
import com.pedigrees.model.domain.Manufacturer;
import com.pedigrees.model.exceptions.ServiceLoadException;
import java.sql.Connection;

import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;
/**
 * @author Ishmael Thomas
 * 
 * It is the implementation interface for the manufacturer registration process. 
 * It implements the IManufacturerRegistrationDBService interface on behalf of the
 * manufacturer registration manager. 
 * 
 * Its uses the createManufacturerProfile method of a string type to accept a 
 * manufacturer profile (data transfer object) as an argument from the manufacturer
 * registration manager to execute the following algorithm:
 * 
 * 1. Copy property information into its data fields from the method argument
 * 2. Load the database driver for the epedigree database.
 * 3. Create a connection to the epedigree database.
 * 4. Authenicate to the epedigree database. 
 * 5. Establish a DML construct using a PreparedStatment for Insert
 * 6. Assign the Insert statement to an SQL string.
 * 7. Insert manufacturer property into data fields in the manufacturer table.
 * 8. Return results.
 * 
 * In addition, it facilitates the storage of the manufacturer's profile  properties 
 * (data access object) in a manufacturer table located in the epedigree database.
 *
 */
public class ManufacturerRegistrationDBSvcImpl implements IManufacturerRegistrationDBService {

String regStatus;
	
	
	@Override
	public String createManufacturerProfile(Manufacturer manufacturer) throws ServiceLoadException {
	
		//Method string variables to hold data properties from the customer DTO
		String mName = null;
		String mUName = null;
		String mPassword = null;
		String mSignature = null;
						
		//Transferring data properties from the manufacturer DTO to method string variables
		
		mName = manufacturer.getManufacturersname();
		mUName = manufacturer.getUsername();
		mPassword = manufacturer.getPassword() ;
		mSignature = manufacturer.getManufacturerssignature();
		
			
		 // create a status code for process
		// "0" returns false
		// Greater than "0" returns true
		
		int queryStatus;
		
		queryStatus = addNewManufacturer(mName,mUName,mPassword,mSignature);
		
		System.out.println(queryStatus);
		
		if(queryStatus > 0){
			
			regStatus = "true";
			
		} else if (queryStatus == 0){
			
			regStatus = "false";
		}// end of query evaluation
		
		     // return status back to customer registration manager
			return regStatus;
} // end of createCustomerProfile method

	private int addNewManufacturer(String mfgName, String mfgUName, String mfgPassword, String mfgSign){
		
		//query results variable
		int result = 0;
		
		//prepared query statement variables
		PreparedStatement insertNewManufacturer = null;
		
		
		//Loading database driver
		Context iniCtx = null;
		try {
			iniCtx = new InitialContext();
		} catch (NamingException e3) {
			System.out.println("can't create iniCtx");
			e3.printStackTrace();
		}
	    Context envCtx = null;
		try {
				envCtx = (Context)iniCtx.lookup("java:comp/env");
				
		} catch (NamingException e2) {
				System.out.println("can't lookup env");
				e2.printStackTrace();
		}
	    DataSource ds = null;
		try {
				ds = (DataSource)envCtx.lookup("jdbc/epedigree");
				
		} catch (NamingException e1) {
				System.out.println("can't lookup the database name");
				e1.printStackTrace();
		}// end of loading database driver

		 
		 //Connecting to database and preparing INSERT statement
		try {
			Connection conn = ds.getConnection();
			insertNewManufacturer = conn.prepareStatement(
			 "INSERT INTO manufacturer " +
			 "(mfg, muname, mupassword, msignature) " +
			 "VALUES (?,?,?,?)");
		} catch (SQLException e) {
			System.out.println("can't connect to the database");
			
			e.printStackTrace();
		}// end of connecting to database and preparing INSERT statement
		
		//Processing the INSERT statement for the mfg field in the manufacturer table 
		try {
			insertNewManufacturer.setString(1, mfgName);
		} catch (SQLException e) {
			System.out.println("can't process 1st insert statement");
			e.printStackTrace();
		}// end of processing INSERT statement for mfg field in the manufacturer table
		
		//Processing the INSERT statement for the muname field in the manufacturer table 
		try {
			insertNewManufacturer.setString(2, mfgUName);
		} catch (SQLException e) {
			System.out.println("can't process 1st insert statement");
			e.printStackTrace();
		}// end of processing INSERT statement for muname field in the manufacturer table
			
		//Processing the INSERT statement for the mupassword field in the manufacturer table 
		try {
			insertNewManufacturer.setString(3, mfgPassword);
		} catch (SQLException e) {
			System.out.println("can't process 1st insert statement");
			e.printStackTrace();
		}// end of processing INSERT statement for mupassword field in the manufacturer table
		
		//Processing the INSERT statement for the msignature field in the customer table 
		try {
			insertNewManufacturer.setString(4, mfgSign);
		} catch (SQLException e) {
			System.out.println("can't process 2nd insert statement");
			e.printStackTrace();
		}// end of processing INSERT statement for msignature field in the customer table
		
		//Capturing the INSERT statement results from the customer table
		try {
			result = insertNewManufacturer.executeUpdate();
		} catch (SQLException e) {
			System.out.println("can't get db execution results");
			e.printStackTrace();
		} 
		
		//Return the results back to createManufacturerProfile method
		System.out.println(result);
		return result;
		
	}// end of addNewManufacturer method
} // end of ManufacturerRegistrationDBSvcImpl Class
