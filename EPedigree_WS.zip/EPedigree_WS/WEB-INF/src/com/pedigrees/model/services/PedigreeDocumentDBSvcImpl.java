/**
 * 
 */
package com.pedigrees.model.services;
import com.pedigrees.model.domain.InitialPedigree;
import com.pedigrees.model.exceptions.ServiceLoadException;
import java.sql.Connection;

import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;
/**
 * @author Ishmael Thomas
 * 
 * It is the implementation interface for the pedigree document creation process. 
 * It implements the IPedigreeDocumentDBService interface on behalf of the
 * pedigree document manager. 
 * 
 * Its uses the createPedigreeDocument method of a string type to accept a 
 * initialPedigree (data transfer object) as an argument from the pedigree
 * document manager to execute the following algorithm:
 * 
 * 1. Copy property information into its data fields from the method argument
 * 2. Load the database driver for the epedigree database.
 * 3. Create a connection to the epedigree database.
 * 4. Authenicate to the epedigree database. 
 * 5. Establish a DML construct using a PreparedStatment for Insert
 * 6. Assign the Insert statement to an SQL string.
 * 7. Insert initial pedigree property into data fields in the initialPedigree table.
 * 8. Return results.
 * 
 * In addition, it facilitates the storage of the initial pedigree properties 
 * (data access object) in the initialPedigree table located in the epedigree database.
 *
 */
public class PedigreeDocumentDBSvcImpl implements IPedigreeDocumentDBService {
	
String regStatus;
	
	
	@Override
	public String createPedigreeDocument(InitialPedigree initialPedigree) throws ServiceLoadException {
	
		//Method string variables to hold data properties from the initialPedigree DTO
		String sNumberInput = null;
		String pInfoInput = null;
		String dNameInput = null;
		String mNameInput = null;
		String iInfoInput = null;
		String lInfoInput = null;
		String qInfoInput = null;
						
		//Transferring data properties from the initialPedigree DTO to method string variables
		 sNumberInput = initialPedigree.getSerialNumber();
		 pInfoInput = initialPedigree.getProductInfo();
		 dNameInput = initialPedigree.getDrugName();
		 mNameInput = initialPedigree.getManufacturer();
		 iInfoInput = initialPedigree.getItemInfo();
		 lInfoInput = initialPedigree.getLot();
		 qInfoInput = initialPedigree.getQuantity();
		
			
		 // create a status code for process
		// "0" returns false
		// Greater than "0" returns true
		
		int queryStatus;
		
		queryStatus = addNewCustomer(sNumberInput,pInfoInput,dNameInput, mNameInput, iInfoInput, lInfoInput, qInfoInput);
		
		System.out.println(queryStatus);
		
		if(queryStatus > 0){
			
			regStatus = "true";
			
		} else if (queryStatus == 0){
			
			regStatus = "false";
		}// end of query evaluation
		
		     // return status back to customer registration manager
			return regStatus;
} // end of createCustomerProfile method

	private int addNewCustomer(String sNumber, String pInfo, String dName, String mName, String iInfo, String lInfo, String qInfo){
		
		//query results variable
		int result = 0;
		
		//prepared query statement variables
		PreparedStatement insertNewPedigree = null;
		
		
		//Loading database driver
		Context iniCtx = null;
		try {
			iniCtx = new InitialContext();
		} catch (NamingException e3) {
			System.out.println("can't create iniCtx");
			e3.printStackTrace();
		}
	    Context envCtx = null;
		try {
				envCtx = (Context)iniCtx.lookup("java:comp/env");
				
		} catch (NamingException e2) {
				System.out.println("can't lookup env");
				e2.printStackTrace();
		}
	    DataSource ds = null;
		try {
				ds = (DataSource)envCtx.lookup("jdbc/epedigree	");
				
		} catch (NamingException e1) {
				System.out.println("can't lookup the database name");
				e1.printStackTrace();
		}// end of loading database driver

		 
		 //Connecting to database and preparing INSERT statement
		try {
			Connection conn = ds.getConnection();
			insertNewPedigree = conn.prepareStatement(
			 "INSERT INTO initialpedigree " +
			 "(snumber, pinfo, dname, mfg, iinfo, linfo, qinfo) " +
			 "VALUES (?,?,?,?,?,?,?)");
		} catch (SQLException e) {
			System.out.println("can't connect to the database");
			
			e.printStackTrace();
		}// end of connecting to database and preparing INSERT statement
		
		
		
		//Processing the INSERT statement for the snumber field in the initialpedigree table 
		try {
			insertNewPedigree.setString(1, sNumber);
		} catch (SQLException e) {
			System.out.println("can't process 1st insert statement");
			e.printStackTrace();
		}// end of processing INSERT statement for snumber field in the customer table
		
		//Processing the INSERT statement for the pinfo field in the initialpedigree table 
		try {
			insertNewPedigree.setString(2, pInfo);
		} catch (SQLException e) {
			System.out.println("can't process 2nd insert statement");
			e.printStackTrace();
		}// end of processing INSERT statement for pinfo field in the initialpedigree table
		
		//Processing the INSERT statement for the dname field in the initialpedigree table 
		try {
			insertNewPedigree.setString(3, dName);
		} catch (SQLException e) {
			System.out.println("can't process 2nd insert statement");
			e.printStackTrace();
		}// end of processing INSERT statement for dname field in the initialpedigree table
		
		//Processing the INSERT statement for the mfg field in the initialpedigree table 
		try {
			insertNewPedigree.setString(4, mName);
		} catch (SQLException e) {
			System.out.println("can't process 2nd insert statement");
			e.printStackTrace();
		}// end of processing INSERT statement for mfg field in the initialpedigree table
		
		//Processing the INSERT statement for the iinfo field in the initialpedigree table 
		try {
			insertNewPedigree.setString(5, iInfo);
		} catch (SQLException e) {
			System.out.println("can't process 2nd insert statement");
			e.printStackTrace();
		}// end of processing INSERT statement for iinfo field in the initialpedigree table
		
		
		//Processing the INSERT statement for the linfo field in the initialpedigree table 
		try {
			insertNewPedigree.setString(6, lInfo);
		} catch (SQLException e) {
			System.out.println("can't process 2nd insert statement");
			e.printStackTrace();
		}// end of processing INSERT statement for linfo field in the initialpedigree table
		
		//Processing the INSERT statement for the qinfo field in the initialpedigree table 
		try {
			insertNewPedigree.setString(7, qInfo);
		} catch (SQLException e) {
			System.out.println("can't process 2nd insert statement");
			e.printStackTrace();
		}// end of processing INSERT statement for qinfo field in the initialpedigree table
		
		//Capturing the INSERT statement results from the customer table
		try {
			result = insertNewPedigree.executeUpdate();
		} catch (SQLException e) {
			System.out.println("can't get db execution results");
			e.printStackTrace();
		} 
		
		//Return the results back to createPedigreeDocument method
		System.out.println(result);
		return result;
		
	}// end of addNewPedigree method

} // end of PedigreeDocumentDBSvcImpl Class
