/**
 * 
 */
package com.pedigrees.model.services;

/**
 * @author Ishmael Thomas
 * 
 * The IService is a base interface (marker for all service interfaces
 * in the com.pedigrees.model.services package.
 *
 */
public interface IService {

} // end of IService
