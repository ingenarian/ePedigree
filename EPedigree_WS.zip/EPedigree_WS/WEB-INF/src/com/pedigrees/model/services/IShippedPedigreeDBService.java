package com.pedigrees.model.services;
import com.pedigrees.model.domain.ShippedPedigree;
import com.pedigrees.model.services.IService;
import com.pedigrees.model.exceptions.ServiceLoadException;
/**
 * @author Ishmael Thomas
 *
 * It is the service interface for the shipped pedigree  implementation. 
 * It extends the IService interface so that it can be located by the
 * shipped pedigree manager through the Service Factory look-up process. 
 * 
 * Its directive is to facilitate the creation of shipped pedigree document (data transfer object) 
 * during the shipped pedigree document creation process. In addition, it facilitates 
 * the storage of the shipped pedigree document  properties (data access object) in an initial table
 * located in the epedigree database. 
 *
 */

public interface IShippedPedigreeDBService extends IService {
			
	/**
	 * 
	 * Separated interface design pattern
	 */
	public final String NAME = "IShippedPedigreeDBService";
	
	/**
	 * 
	 * String type return method to report success or failure 
	 * back to the original caller - shipped pedigree manager
	 * @throws ServiceLoadException 
	 */
	public String createShippedPedigreeDocument(ShippedPedigree shippedPedigree) throws ServiceLoadException;

} // end of IShippedPedigreeDBService Interface
