/**
 * 
 */
package com.pedigrees.model.services;
import com.pedigrees.model.services.IService;
import com.pedigrees.model.domain.Manufacturer;
import com.pedigrees.model.exceptions.ServiceLoadException;

/**
 * @author Ishmael Thomas
 *
 * It is the service interface for the manufacturer registration implementation. 
 * It extends the IService interface so that it can be located by the manufacturer 
 * registration manager through the Service Factory look-up process. 
 * 
 * Its directive is to facilitate the creation of a customer profile (data transfer object) 
 * during the manufacturer registration process. In addition, it facilitates 
 * the storage of the manufacturer's profile  properties (data access object) in a manufacturer table
 * located in the epedigree database. 
 *
 */
public interface IManufacturerRegistrationDBService extends IService{
	
	/**
	 * 
	 * Separated interface design pattern
	 */
	public final String NAME = "IManufacturerRegistrationDBService";
	
	/**
	 * 
	 * String type return method to report success or failure 
	 * back to the original caller - manufacturer registration manager
	 * @throws ServiceLoadException 
	 */
	public String createManufacturerProfile(Manufacturer manufacturer) throws ServiceLoadException;
	
	
	
}// end of IManufacturerRegistrationDBService Interface
