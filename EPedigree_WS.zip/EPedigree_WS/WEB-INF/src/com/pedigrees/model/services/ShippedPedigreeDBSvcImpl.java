/**
 * 
 */
package com.pedigrees.model.services;

/**
 * @author Ish
 *
 */
public class ShippedPedigreeDBSvcImpl {

}
