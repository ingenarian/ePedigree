/**
 * 
 */
package com.pedigrees.model.services;
import com.pedigrees.model.domain.PedigreeEnvelope;
import com.pedigrees.model.services.IService;
import com.pedigrees.model.exceptions.ServiceLoadException;

/**
 * @author Ishmael Thomas
 *
 * It is the service interface for the pedigree envelope creation implementation. 
 * It extends the IService interface so that it can be located by the pedigree 
 * envelope manager through the Service Factory look-up process. 
 * 
 * Its directive is to facilitate the creation of pedigree envelope (data transfer object) 
 * during the pedigree envelope creation process. In addition, it facilitates 
 * the storage of the pedigree's envelope properties (data access object) in an pedigreeenvelope table
 * located in the epedigree database. 
 *
 */
public interface IPedigreeEnvelopeDBService extends IService {

	/**
	 * 
	 * Separated interface design pattern
	 */
	public final String NAME = "IPedigreeEnvelopeDBService";
	
	/**
	 * 
	 * String type return method to report success or failure 
	 * back to the original caller - pedigree envelope manager
	 * @throws ServiceLoadException 
	 */
	public String createPedigreeEnvelope(PedigreeEnvelope pedigreeEnvelope) throws ServiceLoadException;
	
} // end of IPedigreeEnvelopeDBService Interface
