/**
 * 
 */
package com.pedigrees.model.services;
import com.pedigrees.model.services.IService;
import com.pedigrees.model.domain.Credential;
import com.pedigrees.model.exceptions.ServiceLoadException;
/**
 * @author Ishmael Thomas
 *
 * It is the service interface for the Pedigree login authenication and validation implementation. 
 * It extends the IService interface so that it can be located by the Pedigree login 
 * manager through the Service Factory look-up process. 
 * 
 * Its directive is to facilitate the creation of a security token - credential object.
 * It enables the Pedigree login implementation service to compare information (username and password)
 * supplied by a user against information located in a manufacturer's profile (object) stored 
 * in a manufacturer table in the epedigree database. 
 *  
 *
 */
public interface IPedigreeLoginService extends IService {

	/**
	 * 
	 * Separated interface design pattern
	 */
	public final String NAME = "IPedigreeLoginService";
	
	
	/**
	 * 
	 * Boolean type return method to report success or failure 
	 * back to the original caller - Pedigree login manager
	 * @throws ServiceLoadException 
	 */
	public String credentialsChecked(Credential credential)throws ServiceLoadException;
	
} // end of IPedigreeLoginService Interface
