/**
 * 
 */
package com.pedigrees.model.services;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Properties;
import java.util.Set;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

import com.pedigrees.model.domain.Credential;
/**
 * @author Ishmael Thomas
 * 
 * It is the implementation interface for the pedigree login process. 
 * It implements the IPedigreeLoginDBService interface on behalf of the
 * pedigree login manager. 
 * 
 * Its uses the credentialsChecked method of a string type to accept a 
 * credential profile (data transfer object) as an argument from the manufacturer
 * login manager to execute the following algorithm:
 * 
 * 1. Copy property information into its data fields from the method argument
 * 2. Load the database driver for the epedigree database.
 * 3. Create a connection to the epedigree database.
 * 4. Authenicate to the epedigree database. 
 * 5. Establish a DML construct using a PreparedStatment for SELECT
 * 6. Assign the SELECT statement to an SQL string.
 * 7. Establish a results set hold to cuname and cupassword field data from the customer table.
 * 8. Copy cuname and cupassword field data into the validateNameCredentials and validatePasswordCredentials methods
 * 9. Return the validation results.
 * 
 */
public class PedigreeLoginSvcImpl implements IPedigreeLoginService{

String regStatus;
	
	@Override
	public String credentialsChecked(Credential credential) {
		//Method string variables to hold data properties from the credential DTO
		String cUName = null;
		String cUPWord = null;
						
		//Transferring data properties from the credential DTO to method string variables
		cUName = credential.getProposedUsersName();
		cUPWord = credential.getProposedUsersPassword();
	
		 // create a status code for process
		// "0" returns false
		// Greater than "0" returns true
		
		int queryStatus1;
		int queryStatus2;
		
		queryStatus1 = validateNameCredentials(cUName);
		queryStatus2 = validatePasswordCredentials(cUPWord);
		
		System.out.println(queryStatus1);
		System.out.println(queryStatus2);
		
		// Evaluate and process queryStatus from customer credentials validation 
		if(queryStatus1 == 1 && queryStatus2 == 1){
						 				
			regStatus = "true";
			
		} else if(queryStatus1 == 1 && queryStatus2 == 0){
			
			regStatus = "false";
			
		} else if(queryStatus1 == 0 && queryStatus2 == 1){
			
			regStatus = "false";
			
		} else if(queryStatus1 == 0 && queryStatus2 == 0){
			
			regStatus = "false";
		}// end of query evaluation
		
		     // return status back to customer login manager
			return regStatus;
	}// end of credentialsChecked Method

	/**
	 * Used to validate a user's login name supplied in the public login
	 * web form against an authorized user's name held in the manufacturer 
	 * table in the epedigree database. It load a database driver,
	 * connects to the epedigree database, and processes the 
	 * SELECT prepared statement. It creates a results set and
	 * compares data values for the user's name. It returns a false 
	 * or true token back to the credentialsCheckedMethod
	 * 
	 */
	public int validateNameCredentials(String usersLoginName){
		
		//Placeholder for proposed user name for validation 
		String proposedUsersName = usersLoginName;
		
		
		//query result set variable
		ResultSet resultSet = null;
		
		//query status variable
		int queryStatus1 = 0;
		
		//prepared query statement variables
		PreparedStatement selectManufacturerByUserName = null;
		
		
		//Loading database driver
		Context iniCtx = null;
		try {
			iniCtx = new InitialContext();
		} catch (NamingException e3) {
			System.out.println("can't create iniCtx");
			e3.printStackTrace();
		}
	    Context envCtx = null;
		try {
				envCtx = (Context)iniCtx.lookup("java:comp/env");
				
		} catch (NamingException e2) {
				System.out.println("can't lookup env");
				e2.printStackTrace();
		}
	    DataSource ds = null;
		try {
				ds = (DataSource)envCtx.lookup("jdbc/epedigree");
				
		} catch (NamingException e1) {
				System.out.println("can't lookup the database name");
				e1.printStackTrace();
		}// end of loading database driver

		 
		 //Connecting to database and preparing SELECT statement
		try {
			Connection conn = ds.getConnection();
			selectManufacturerByUserName = conn.prepareStatement(
					"SELECT muname FROM manufacturer");
		} catch (SQLException e) {
			System.out.println("can't connect to the database");
			
			e.printStackTrace();
		}// end of connecting to database and preparing SELECT statement
		
		
		/*
		//Processing the SELECT statement for the cuname field in the customer table 
		try {
			selectManufacturerByUserName.setString(1, proposedUsersName);
		} catch (SQLException e) {
			System.out.println("can't process SELECT statement");
			e.printStackTrace();
		}// end of processing SELECT statement for cuname field in the customer table
		*/
				
		//Capturing the SELECT statement results from the customer table
		try {
			
			//Hold authorized user's name from the customer table in homeworkexample database
			String authorizedUsersName = null;
			
			resultSet = selectManufacturerByUserName.executeQuery();
			
			while (resultSet.next())
			{
				authorizedUsersName = resultSet.getString(1);
			} // end of while loop
		
			
			//Establish a properties map table to store
			//key (authorizedUsersName) and
			//value (proposedUsersName) pair
			Properties table1 = new Properties();
			table1.setProperty(authorizedUsersName, proposedUsersName);
			
			//Visual references
			System.out.println("This is the submitted login name:   " + proposedUsersName);
			System.out.println("This is the user's authorized login name:   " + authorizedUsersName);
			listProperties(table1);
			
			
			//Get string value of authorizedUsersName
			String value1 = table1.getProperty(authorizedUsersName);
			System.out.println(authorizedUsersName);
			
			//compare string values
			if(value1 != proposedUsersName){
				System.out.println("they're not equal");
				queryStatus1 = 0;
			} else {
				System.out.println("they're equal");
				queryStatus1 = 1;
			}
			/*
			//Compare the two validation variables and creates a queryStatus result
			if (authorizedUsersName == proposedUsersName){
				queryStatus1 = 0; //bad result - reverse logic
				}
			
			else if (authorizedUsersName != proposedUsersName){
				queryStatus1 = 1; //good result - reverse logic
			   }
			*/
		} catch (SQLException e) {
			System.out.println("can't get db execution results");
			e.printStackTrace();
		} // end of capturing the SELECT statement results from the customer table
		
				//return a true or false string to the calling party
		
		System.out.println("hello queryStatus1:  " +queryStatus1);
		return queryStatus1;
	}// end of validateNameCredentials
	
	//List Key (authorizedUsersName) and Value (proposedUsersName) pair
	private void listProperties(Properties table1) {
		
		Set<Object>keys = table1.keySet();
		
		for (Object key : keys)
			System.out.printf("%s\t%s\n", key, table1.getProperty((String)key));
	}
	
	/**
	 * Used to validate a user's login password supplied in the public login
	 * web form against an authorized user's password held in the manufacturer 
	 * table in the epedigree database. It load a database driver,
	 * connects to the epedigree database, and processes the 
	 * SELECT prepared statement. It creates a results set and
	 * compares data values for the user's password. It returns a false 
	 * or true token back to the credentialsCheckedMethod
	 * 
	 */
	public int validatePasswordCredentials(String usersLoginPassword){
		
		//Placeholder for proposed user password for validation 
		String proposedUsersPassword = usersLoginPassword;
		
		
		//query result set variable
		ResultSet resultSet = null;
		
		//query status variable
		int queryStatus2 = 0;
		
		//prepared query statement variables
		PreparedStatement selectManufacturerByUserPassword = null;
		
		
		//Loading database driver
		Context iniCtx = null;
		try {
			iniCtx = new InitialContext();
		} catch (NamingException e3) {
			System.out.println("can't create iniCtx");
			e3.printStackTrace();
		}
	    Context envCtx = null;
		try {
				envCtx = (Context)iniCtx.lookup("java:comp/env");
				
		} catch (NamingException e2) {
				System.out.println("can't lookup env");
				e2.printStackTrace();
		}
	    DataSource ds = null;
		try {
				ds = (DataSource)envCtx.lookup("jdbc/epedigree");
				
		} catch (NamingException e1) {
				System.out.println("can't lookup the database name");
				e1.printStackTrace();
		}// end of loading database driver

		 
		 //Connecting to database and preparing SELECT statement
		try {
			Connection conn = ds.getConnection();
			selectManufacturerByUserPassword = conn.prepareStatement(
			 "SELECT mupassword From manufacturer");
		} catch (SQLException e) {
			System.out.println("can't connect to the database");
			
			e.printStackTrace();
		}// end of connecting to database and preparing SELECT statement
		
	    /*
		//Processing the SELECT statement for the cupassword field in the customer table 
		try {
			selectManufacturerByUserPassword.setString(1, proposedUsersPassword);
		} catch (SQLException e) {
			System.out.println("can't process SELECT statement");
			e.printStackTrace();
		}// end of processing SELECT statement for cuname field in the customer table
		*/
				
		//Capturing the SELECT statement results from the customer table
		try {
			
			//Hold authorized user's password from the customer table in homeworkexample database
			String authorizedUsersPassword = null;
			
			
			resultSet = selectManufacturerByUserPassword.executeQuery();
			
			while (resultSet.next())
			{
				authorizedUsersPassword = resultSet.getString(1);
			} // end of while loop
			
			//Establish a properties map table to store
			//key (authorizedUsersName) and
			//value (proposedUsersName) pair
			Properties table2 = new Properties();
			table2.setProperty(authorizedUsersPassword, proposedUsersPassword);
			
			//Visual references
			System.out.println("This is the submitted login password:   " + proposedUsersPassword);	
			System.out.println("This is the user's authorized login password:   " +authorizedUsersPassword);
			listProperties(table2);
			
			
			//Get value of authorizedUsersName
			Object value2 = table2.getProperty(authorizedUsersPassword);
			
			//Check if value is in table
			if(value2.equals(proposedUsersPassword)){
				System.out.println("they're equal");
				queryStatus2 = 1;
			} else {
				System.out.println("they're not equal");
				queryStatus2 = 0;
			}
			
			
			/*
			//Compare the two validation variables and creates a queryStatus result
			if (authorizedUsersPassword == proposedUsersPassword ){
				queryStatus2 = 0; //bad result - reverse logic
				}
			
			else if (authorizedUsersPassword != proposedUsersPassword){
				queryStatus2 = 1; //good result -reverse logic
			   }
			*/
			
		} catch (SQLException e) {
			System.out.println("can't get db execution results");
			e.printStackTrace();
		} // end of capturing the SELECT statement results from the customer table
		
				//return a true or false string to the calling party
		
		System.out.println("hello queryStatus2:  " +queryStatus2);
		return queryStatus2;
		
	}// end of validatePasswordCredentials
	
}// end of PedigreeLoginSvcImpl Class
