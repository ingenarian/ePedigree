/**
 * 
 */
package com.pedigrees.model.manager;

import junit.framework.TestCase;

/**
 * @author Ish
 *
 */
public class ManufacturerRegistrationManagerTest extends TestCase {

	/**
	 * Test method for {@link com.pedigrees.model.manager.ManufacturerRegistrationManager#validate(java.lang.String, java.lang.String, java.lang.String, java.lang.String)}.
	 */
	public void testValidate() {
		
		ManufacturerRegistrationManager manufacturerRegistrationManager = new ManufacturerRegistrationManager();
		String mName = "";
		String mUName = "";
		String mPassword = "";
		String mSignature = "";
		String status = manufacturerRegistrationManager.validate(mName, mUName, mPassword, mSignature);
		assertEquals("false", status);
		
	} // end of testValidate

} // end of ManufacturerRegistrationManagerTest
