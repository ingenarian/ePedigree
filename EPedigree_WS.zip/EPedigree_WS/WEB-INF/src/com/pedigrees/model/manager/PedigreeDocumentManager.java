/**
 * 
 */
package com.pedigrees.model.manager;
import com.pedigrees.model.domain.InitialPedigree;
import com.pedigrees.model.exceptions.ServiceLoadException;
import com.pedigrees.model.factory.ServiceFactory;
import com.pedigrees.model.services.IPedigreeDocumentDBService;


/**
*
* @author Ishmael Thomas
* 
* The Pedigree Document Manager validates for correct input by the user 
* as they are creating a new pedigree document.
*
*/
public class PedigreeDocumentManager {

	/**
	 * No argument PedigreeDocumentManager Constructor
	 */
	public PedigreeDocumentManager(){
		
	} // end of PedigreeDocumentManager Constructor
	
	/**
	 * Validate product name, product manufacturer's name, and universal product code (UPC)
	 */
	public String validate(String sNumber, String pInfo, String dName, String mName, String iInfo, String lInfo, String qInfo){
		
		// Establish validation variables
		int count = 7;
		
		String status = null;
		String sNumberInput = sNumber;
		String pInfoInput = pInfo;
		String dNameInput = dName;
		String mNameInput = mName;
		String iInfoInput = iInfo;
		String lInfoInput = lInfo;
		String qInfoInput = qInfo;
		
		// Validate pedigree serial number (version) input from user
		if (sNumberInput != ""){
			count--;
		}
		
		// Validate  product's drug description input from user
		if (pInfoInput != ""){
			count--;
		}
		
		// Validate product's drug name input from user
		if(dNameInput != ""){
			count--;
		}
		
		// Validate product's drug manufacturer input from user
		if(mNameInput != ""){
			count--;
		}
		
		// Validate product's UPC (universal product code) input from user
		if(iInfoInput != ""){
			count--;
		}
		
		// Validate product's lot size (number of cases) input from user
		if(lInfoInput != ""){
			count--;
		}
		
		// Validate product's quantity (each count per case) input from user
		if(qInfoInput != ""){
			count--;
		}
		
		
		// Evaluate validation to process with a success message
		if (count == 0){
								
			status = process(sNumberInput,pInfoInput, dNameInput, mNameInput, iInfoInput, lInfoInput, qInfoInput);
		
		// Evaluate validation to process with a failure message
		} else if (count > 0){
			
			
			status = "false";
		}
		// Send status back to Product Creation Controller
		return status;
		
	}// end of validate Method
	
	// -- Method below: future design will include JDBC SQL Insert Statement
	/**
	 * Private Process Method to create pedigree (initial) java bean
	 */
	private String process(String sNumberInput, String pInfoInput, String dNameInput, String mNameInput, String iInfoInput, String lInfoInput, String qInfoInput){
		
		// Establish process variables
		String processResults = null;
		String sNumber = sNumberInput;
		String pInfo = pInfoInput;
		String dName = dNameInput;
		String mName = mNameInput;
		String iInfo = iInfoInput;
		String lInfo = lInfoInput;
		String qInfo = qInfoInput;
		
		//Create a pedigree (initial) object DTO and set the properties with input from the user
		InitialPedigree initialPedigree = new InitialPedigree();
		initialPedigree.setSerialNumber(sNumber);
		initialPedigree.setProductInfo(pInfo);
		initialPedigree.setDrugName(dName);
		initialPedigree.setManufacturer(mName);
		initialPedigree.setItemInfo(iInfo);
		initialPedigree.setLot(lInfo);
		initialPedigree.setQuantity(qInfo);
		
				
		System.out.println(initialPedigree.getSerialNumber());
		System.out.println(initialPedigree.getProductInfo());
		System.out.println(initialPedigree.getDrugName());
		System.out.println(initialPedigree.getManufacturer());
		System.out.println(initialPedigree.getItemInfo());
		System.out.println(initialPedigree.getLot());
		System.out.println(initialPedigree.getQuantity());
		
		//Creating a Service Factory instance
		ServiceFactory serviceFactory = ServiceFactory.getInstance();
		
		//Establishing a Service bond
		IPedigreeDocumentDBService pedDocDBSvc = null;
		try {
			pedDocDBSvc = (IPedigreeDocumentDBService)serviceFactory.getService(IPedigreeDocumentDBService.NAME);
		} catch (ServiceLoadException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}// end of Service bond
		
		//Calling the Service implementation, 
		//passing the initialPedigree DTO into the service implementation method, 
		//and collecting processing results
		try {
			processResults = pedDocDBSvc.createPedigreeDocument(initialPedigree);
		} catch (ServiceLoadException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}// end of Service implementation call
			
		//Return results back to the Validation Method
		return processResults;
	}// end of Process
	
} // end of PedigreeDocumentManager
