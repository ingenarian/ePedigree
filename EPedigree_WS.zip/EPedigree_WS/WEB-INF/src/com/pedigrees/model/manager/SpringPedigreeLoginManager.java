package com.pedigrees.model.manager;

import com.pedigrees.model.domain.Credential;
import com.pedigrees.model.factory.ServiceFactory;
import com.pedigrees.model.services.IPedigreeLoginService;
import com.pedigrees.model.domain.Manufacturer;
import com.pedigrees.model.exceptions.ServiceLoadException;

/**
 * @author Ishmael Thomas
 * 
 * The Spring Pedigree Login Manager works with the
 * Spring Pedigree Login Controller to authenticate the
 * user's input from the ePedigreeAppLogin jsp page 
 * against the credentials stored in the customer's MySQL
 * table. 
 *
 */
public class SpringPedigreeLoginManager {
	/**
	 * No Argument SpringPedigreeLoginManager Constructor
	 */
	
	public SpringPedigreeLoginManager(){
		
	}// end of SpringPedigreeLoginManager Constructor
	
	
	/**
	 * Public Process Method to create credential java bean
	 */
	public String process(Manufacturer manufacturer){
	
		// Establish process variables
		
		String name = manufacturer.getUsername();
		String password = manufacturer.getPassword();
		String processResults = null;
		
//Create a credential data transfer object (DTO) and setting the properties with input from the user
		
		Credential credential = new Credential();
		credential.setProposedUsersName(name);
		credential.setProposedUsersPassword(password);
						
		System.out.println(credential.getProposedUsersName());
		System.out.println(credential.getProposedUsersPassword());
		
		
		//Creating a Service Factory instance
		ServiceFactory serviceFactory = ServiceFactory.getInstance();
		
		
		//Establishing a Service bond
		IPedigreeLoginService mfgValDBSvc = null;
		try {
			mfgValDBSvc = (IPedigreeLoginService)serviceFactory.getService(IPedigreeLoginService.NAME);
		} catch (ServiceLoadException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}// end of Service bond
		
		//Calling the Service implementation, 
		//passing the credential DTO into the service implementation method, 
		//and collecting processing results
		try {
			processResults = mfgValDBSvc.credentialsChecked(credential);
		} catch (ServiceLoadException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}// end of Service implementation call
				
		//Return results back to the Validation Method
		return processResults; 
		
	}// end of process method to create credential java bean
		
		
}// end of SpringPedigreeLoginManager
