/**
 * 
 */
package com.pedigrees.model.manager;

import junit.framework.TestCase;

/**
 * @author Ishmael Thomas
 * 
 * A JUnit Test for the PedigreeLoginManager's validate method invoked by the PedigreeLoginController.
 *
 */
public class PedigreeLoginManagerTest extends TestCase {

	/**
	 * 
	 
	 * Test method for {@link com.pedigrees.model.manager.PedigreeLoginManager#validate(java.lang.String, java.lang.String)}.
	 */
	public void testValidate() {
		
		PedigreeLoginManager pedigreeLoginManager = new PedigreeLoginManager();
		
				
		String usersLogin = "";
		String usersPassword = "";
		pedigreeLoginManager.validate(usersLogin, usersPassword);
		
		
		
		
		
		
	} // end of testValidate

} // end of PedigreeLoginManagerTest
