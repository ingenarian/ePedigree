/**
 * 
 */
package com.pedigrees.model.manager;

import junit.framework.TestCase;

/**
 * @author Ish
 *
 */
public class PedigreeDocumentManagerTest extends TestCase {

	/**
	 * Test method for {@link com.pedigrees.model.manager.PedigreeDocumentManager#validate(java.lang.String, java.lang.String, java.lang.String, java.lang.String, java.lang.String, java.lang.String, java.lang.String)}.
	 */
	public void testValidate() {
		
		PedigreeDocumentManager pedigreeDocumentManager = new PedigreeDocumentManager();
		
		String serial = "";
		String mfg = "";
		String drug = "";
		String item = "";
		String product = "";
		String lot = "";
		String quantity = "";
		String status = pedigreeDocumentManager.validate(serial, mfg, drug, item, product, lot, quantity);
		assertEquals("false", status);
		
		
	} // end of testValidate

} // end of PedigreeDocumentManagerTest
