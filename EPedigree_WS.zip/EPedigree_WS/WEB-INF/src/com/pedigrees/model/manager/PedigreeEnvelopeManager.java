/**
 * 
 */
package com.pedigrees.model.manager;

/**
 * @author Ish
 *
 */
public class PedigreeEnvelopeManager {

}
