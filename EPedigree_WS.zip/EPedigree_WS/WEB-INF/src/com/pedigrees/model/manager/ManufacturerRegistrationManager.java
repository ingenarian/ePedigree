/**
 * 
 */
package com.pedigrees.model.manager;


import com.pedigrees.model.exceptions.ServiceLoadException;
import com.pedigrees.model.factory.ServiceFactory;
import com.pedigrees.model.services.IManufacturerRegistrationDBService;
import com.pedigrees.model.domain.Manufacturer;
/**
 * @author Ishmael Thomas
 * 
 * The Manufacturer Registration Manager executes the business rules for the use case.
 * It uses a validation method to check if the user filled-in the data entry fields
 * on the manufacturer's registration form. If the validation is true, then a manufacturer java bean is 
 * created with the user's input and is persisted. 
 *
 */
public class ManufacturerRegistrationManager {

	/**
	 * No Argument ManufacturerRegistrationManager Constructor
	 */
	public ManufacturerRegistrationManager(){
		
	}// end of ManufacturerRegistrationManager Constructor

	
	/**
	 * Validation Method for user's name and password
	 */
	public String validate(String mfgName, String mfgUsersName,  String mfgPassword, String mfgSignature){
		
		// Establish validation variables
		int count = 4;
		String status = null;
		String mfgNameInput = mfgName;
		String mfgUNameInput = mfgUsersName;
		String mfgPasswordInput = mfgPassword;
		String mfgSignInput = mfgSignature;
		
		// Validate Manufacturer's name input from user
		if (mfgNameInput != ""){
			count--;
		}
		
		// Validate Manufacturer user's name input from user
		if (mfgUNameInput != ""){
			count--;
		}
		
		// Validate Manufacturer's password input from user
		if (mfgPasswordInput != ""){
			count--;
		}
		
		// Validate Manufacturer's signature input from user
		if (mfgSignInput != ""){
			count--;
		}
		
		// Evaluate validation to process with a success message
		if (count == 0){
								
			status = process(mfgNameInput, mfgUNameInput, mfgPasswordInput, mfgSignInput);
		
		// Evaluate validation to process with a failure message
		} else if (count > 0){
			
			status = "false";
		}
		// Send status back to Manufacturer Registration Controller
		return status;
	} //end of Validate
	
	// -- Method below: future design will include JDBC SQL Insert Statement
	/**
	 * Private Process Method to create manufacturer java bean
	 */
	private String process(String mfgName, String mfgUName, String mfgPassword, String mfgSign){
		
		// Establish process variables
		String processResults = null;
		String mName = mfgName;
		String mUName = mfgUName;
		String mPassword = mfgPassword;
		String mSignature = mfgSign;
		
		//Create a manufacturer object DTO and set the properties with input from the user
		Manufacturer manufacturer = new Manufacturer();
		manufacturer.setManufacturersname(mName);
		manufacturer.setUsername(mUName);
		manufacturer.setPassword(mPassword);
		manufacturer.setManufacturerssignature(mSignature);
		System.out.println(manufacturer.getManufacturersname());
		System.out.println(manufacturer.getUsername());
		System.out.println(manufacturer.getPassword());
		System.out.println(manufacturer.getManufacturerssignature());
		
		//Creating a Service Factory instance
		ServiceFactory serviceFactory = ServiceFactory.getInstance();
		
		//Establishing a Service bond
		IManufacturerRegistrationDBService mfgRegDBSvc = null;
		try {
			mfgRegDBSvc = (IManufacturerRegistrationDBService)serviceFactory.getService(IManufacturerRegistrationDBService.NAME);
		} catch (ServiceLoadException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}// end of Service bond
		
		//Calling the Service implementation, 
		//passing the manufacturer DTO into the service implementation method, 
		//and collecting processing results
		try {
			processResults = mfgRegDBSvc.createManufacturerProfile(manufacturer);
		} catch (ServiceLoadException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}// end of Service implementation call
			
		//Return results back to the Validation Method
		return processResults;
	}// end of Process
}// end of ManufacturerRegistrationManager
