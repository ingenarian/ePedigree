/**
 * 
 */
package com.pedigrees.model.domain;

import java.io.Serializable;

import javax.validation.constraints.Size;


/**
 * @author Ishmael Thomas
 * 
* It facilitates the registration of a new user profile (manufacturer)
 * for the e-Pedigree web application. In addition, it captures the
 * manufacturer's access credentials (username and password) for the
 * credential object to facilitate the e-Pedigree web application login process
 * (authorization and authentication).
 * 
 *
 */
public class Manufacturer implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 3220896249025377727L;
	
	/**
	 * No Argument Constructor of Manufacturer Class
	 */
	public Manufacturer(){
		
	}// end of Manufacturer Constructor
	
	/**
	 * Used to hold the manufacturer's registration name and 
	 * the name used on pedigree documents 
	 */
	private String manufacturersname;
	
	/**
	 * Used to hold the manufacturer's login name
	 */
	@Size(min=1, message="username is required.")
	private String username;
	
	/**
	 * Used to hold the manufacturer's login password
	 */
	@Size(min=1, message="password is required.")
	private String password;
	
	/**
	 * Used to hold the manufacturer's signature and 
	 * used in pedigree transactions
	 */
	private String manufacturerssignature;
	
	
	/**
	 * Returns the name of manufacturing company created
	 * during the initial registration process and for 
	 * the pedigree document creation process.
	 */
	public String getManufacturersname(){
		
		return manufacturersname;
	}// end of getManufacturersname
	
	/**
	 * Sets the name of the manufacturing company during 
	 * the initial registration process.
	 */
	public void setManufacturersname (String manufacturersname){
	
		this.manufacturersname = manufacturersname;
	}// end of setManufacturersName
	
	/**
	 * Returns the username of a registered user (authorized personnel)
	 * 
	 */
	public String getUsername(){
	
		return username;
	}// end of getUsername
	
	/**
	 * Sets a username for authorized personnel during the registration 
	 * process.  
	 */
	public void setUsername(String username){
		
		this.username = username;
	}// end of setManufacturersUserName
	
	/**
	 * Returns the password associated with a username 
	 */
	public String getPassword(){
		
		return password;
	} // end of getManufacturersPassword
	
	/**
	 * Sets the password associated with a username
	 */
	public void setPassword(String password){
		
		this.password = password;
	} // end of setPassword
	
	/**
	 * Returns a signature to enabled authorized personnel to sign pedigree 
	 * documents on behalf on the manufacturing company
	 */
	public String getManufacturerssignature(){
		
		return manufacturerssignature;
	}// end of the getManufacturersSignature
	
	/**
	 * Sets a signature field to hold an authorized signature on behalf of the
	 * manufacturing company
	 */
	public void setManufacturerssignature(String manufacturerssignature){
		
		this.manufacturerssignature = manufacturerssignature;
	}// end of the setManufacturersSignature
	
} // end of the Manufacturer Class
