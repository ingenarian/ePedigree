/**
 * 
 */
package com.pedigrees.model.domain;
import com.pedigrees.model.domain.InitialPedigree;
import java.io.Serializable;
import java.util.LinkedHashSet;

/**
 * @author Ishmael Thomas
 * 
 * The ShippedPedigree is a class representing the
 * information about a transaction in which ownership of
 * the drug product passes from manufacturer to distributor.
 * It contains one or more initial pedigrees. It is created by a 
 * pharmaceutical manufacturer for drug distribution. 
 * It is the central domain object for
 * the second use case -  Ship a pedigree.
 */
public class ShippedPedigree implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 8321692189901048357L;

	/**
	 * ShipeedPedigree Constructor 
	 */
	public ShippedPedigree(){
		
	}// end of ShippedPedigree Constructor
	
	/**
	 * Used to identify a shipped pedigree document 
	 */
	private String id;
	
	/**
	 * Used to identify the pedigree sub-type and version: initial or repackaged
	 */
	private String documentInfo;
	
	/**
	 * Used to identify the product change of ownership information 
	 */
	private String transactionInfo;
	
	/**
	 * Used to identify the supply chain partner sending the shipment 
	 */
	private String senderInfo;
	
	/**
	 * Used to identify the supply chain partner receiving the shipment 
	 */
	private String recipientInfo;
	
	/**
	 * Used to identify the transaction by business document type: PO#, Invoice#, and ASN# 
	 */
	private String transactionIdentifier;
	
	/**
	 *  Used to identify the signer and context (i.e certified) of the pedigree
	 */
	private String signatureInfo;
	
	/**
	 * Used to hold a set of initial pedigrees
	 */
	private LinkedHashSet<InitialPedigree> pedigreeCollection;
	
			
	/**
	 * Returns the shipped pedigree ID 
	 */
	public String getID(){
		
		return id;
	}// end of getID
	
	/**
	 * Sets the shipped pedigree ID 
	 */
	public void setID(String id){
		
		this.id = id;
	}// end of setID
	
	/**
	 * Returns the pedigree sub-type and version 
	 */
	public String getDocumentInfo(){
		
		return documentInfo;
	}// end of getDocumentInfo
	
	/**
	 * Sets the pedigree sub-type and version 
	 */
	public void setDocumentInfo(String documentInfo){
		
		this.documentInfo = documentInfo;
	}// end of setDocumentInfo
	
	/**
	 * Returns the product change of ownership information 
	 */
	public String getTransactionInfo(){
		
		return transactionInfo;
	}// end of getTransactionInfo
	
	/**
	 * Sets the product change of ownership information 
	 */
	public void setTransactionInfo(String transactionInfo){
	
		this.transactionInfo = transactionInfo;
	}// end of setTransactionInfo
	
	/**
	 * Returns the sender's information 
	 */
	public String getSenderInfo(){
		
		return senderInfo;
	}// end of getSenderInfo
	
	/**
	 * Sets the sender's information 
	 */
	public void setSenderInfo(String senderInfo){
		
		this.senderInfo = senderInfo;
	}// end of setSenderInfo
	
	/**
	 * Returns the receiver's information 
	 */
	public String getRecipientInfo(){
		
		return recipientInfo;
	}// end of getRecipientInfo
	
	/**
	 * Sets the receiver's information 
	 */
	public void setRecipientInfo(String recipientInfo){
		
		this.recipientInfo = recipientInfo;
	}// end of setRecipientInfo
	
	/**
	 * Returns the transaction identifier (business document type) 
	 */
	public String getTransactionIdentifier(){
		
		return transactionIdentifier;
	}// end of getTransactionIdentifier
	
	/**
	 * Sets the transaction identifier (business document type) 
	 */
	public void setTransactionIdentifier(String transactionIdentifier){
		
		this.transactionIdentifier = transactionIdentifier;
	}// end of setTransactionIdentifier
	
	/**
	 * Returns the signer and context of the pedigree 
	 */
	public String getSignatureInfo(){
		
		return signatureInfo;
	}// end of getSignatureInfo
	
	/**
	 * Sets the signer and context of the pedigree 
	 */
	public void setSignatureInfo(String signatureInfo){
		
		this.signatureInfo = signatureInfo;
	}// end of setSignatureInfo
		
	/**
	 * Returns a set of initial pedigrees
	 */
	public LinkedHashSet<InitialPedigree> getPedigreeCollection(){
		
		return pedigreeCollection;
	}// end of getPedigreeCollection
	
	/**
	 * Establishes a set of initial pedigrees
	 */
	public void setPedigreeCollection(LinkedHashSet<InitialPedigree> pedigreeCollection ){
		
		this.pedigreeCollection = pedigreeCollection;
	}// end of setPedigreeCollection
	
	
} // end of the ShippedPedigee Class
