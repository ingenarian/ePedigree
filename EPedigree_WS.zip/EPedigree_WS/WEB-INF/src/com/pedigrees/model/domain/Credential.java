package com.pedigrees.model.domain;

import java.io.Serializable;


/**
 * @author Ishmael Thomas
 * 
 * The Credential object is a data transfer object.
 * It contains the following variables:
 * 
 * proposedUsersName - holds the login name supplied by the user
 * proposedUsersPassword - hold the login password supplied by the user
 * 
 * 
 * It make those variables available for the following method validation methods
 * in the PedigreeLoginDBSvcImpl:
 * 
 * validateNameCredentials - compares proposed user's name against authorized user's name 
 * validatePasswordCredentials - compares proposed user's password against authorized user's password
 * 
 * These methods are used to validate user's login name and password against
 * the name and password stored in the customer object that was created
 * in the customer registration process. A token message of "true" or
 * "false" is passed back to the credentialchecked method. 
 */
public class Credential implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1376672488928546201L;
	
	/**
	 * Used to hold the supplied login name from the login web form for name verification   
	 */
	private String proposedUsersName;
	
		
	/**
	 * Used to hold the supplied login password from the login web form for password verification   
	 */
	private String proposedUsersPassword;
		
	/**
	 * Returns the password proposed by the user   
	 */
	public String getProposedUsersPassword(){
		
		return proposedUsersPassword;
	}// end of getProposedUsersPassword
	
	/**
	 * Accepts the password proposed by the user   
	 */
	public void setProposedUsersPassword(String proposedUsersPassword){
		
		this.proposedUsersPassword = proposedUsersPassword;
	}// end of setProposedUsersPassword
		
	/**
	 * Returns the login name proposed by the user   
	 */
	public String getProposedUsersName(){
		
		return proposedUsersName;
	}// end of getProposedUsersName
	
	/**
	 * Accepts the login name proposed by the user   
	 */
	public void setProposedUsersName(String proposedUsersName){
		
		this.proposedUsersName = proposedUsersName;
	}// end of setProposedUsersName
	
	
} // end of Credential Class
