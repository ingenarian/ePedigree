/**
 * 
 */
package com.pedigrees.model.domain;
import com.pedigrees.model.domain.ShippedPedigree;
import java.io.Serializable;
import java.util.LinkedHashSet;
/**
 * @author Ishmael Thomas
 * 
 * The PedigreeEnvelope is a class representing an electronic
 * wrapper used to transmit a collection of pedigrees associated 
 * with an outbound customer shipment. 
 * 
 * In addition, the matching of products received to their corresponding 
 * pedigrees is a requirement of the pedigree process. 
 * Therefore, the PedigreeEnvelope faciliates a one-to-one mapping 
 * to items in the shipment (e.g., one initial pedigree per item)
 * to meet government compliance.
 *
 * Last, the PedigreeEnvelope is a central domain object
 * for the third use case -  Transmit an electronic envelope.
 */

public class PedigreeEnvelope implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1280968640122079224L;
	
	/**
	 * Used to hold the pedigree envelope version 
	 */
	private String version;
	/**
	 * Used to hold the pedigree envelope serial number
	 */
	private String pESerialNumber;
	
	/**
	 * Used to hold the date of the pedigree envelope
	 */
	private String date;
		
	/**
	 * Used to hold the sender and recipient's information from a pedigree shipment
	 */
	private ShippedPedigree routingInfo;
	
	/**
	 * Used to hold the container code for pedigree shipments
	 */
	private String containerCode;
		
	/**
	 * Used to hold a set of pedigrees ready for shipment 
	 */
	private LinkedHashSet<ShippedPedigree> pedigreeShipment;

	/**
	 * Returns the version of the pedigree envelope 
	 */
	public String getVersion(){
		
		return version;
	}// end of getVersion
	
	/**
	 * Set the version for the pedigree envelope
	 */
	public void setVersion(String version){
		
	}// end of setVersion
	
	/**
	 * Returns the serial number of the pedigree envelope
	 */
	public String getPESerialNumber(){
		
		return pESerialNumber;
	}// end of getPESerialNumber
	
	/**
	 * Sets the serial number for the pedigree envelope
	 */
	public void setPESerialNumber(String pESerialNumber){
		
	}// end of setPESerialNumber
	
	
	/**
	 * Returns the date of the pedigree envelope
	 */
	public String getDate(){
		
		return date;
	}// end of getDate
	
	/**
	 * Sets the date for the pedigree envelope
	 */
	public void setDate(String date){
		
	}// end of setDate
	
	
	/**
	 * Returns the routing information of pedigree envelope 
	 */
	public ShippedPedigree getRoutingInfo(){
		
		return routingInfo;
	}// end of getRoutingInfo
	
	
	/**
	 * Sets the routing information for the pedigree envelope 
	 */
	public void setRoutingInfo(ShippedPedigree routingInfo){
		
	}// end of setRoutingInfo
	
	/**
	 * Returns the container code of the pedigree envelope
	 */
	public String getContainerCode(){
		
		return containerCode;
	}// end of getContainerCode
	
	/**
	 * Sets the container code for the pedigree envelope
	 */
	public void setContainerCode(){
		
	}// end of setContainerCode
	
	/**
	 * Returns a set of pedigrees ready of shipment
	 */
	public LinkedHashSet<ShippedPedigree> getPedigreeShipment(){
		
		return pedigreeShipment;
	}// end of getPedigreeShipment
	
	/**
	 * Establishes a set of pedigree for shipment
	 */
	public void setPedigreeShipment(LinkedHashSet<ShippedPedigree> pedigreeShipment){
		
		this.pedigreeShipment = pedigreeShipment;
	}// end of setPedigreeShipment
	
	
}// end of PedigreeEnvelope Class
