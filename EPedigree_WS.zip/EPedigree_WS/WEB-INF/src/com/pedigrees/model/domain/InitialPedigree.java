/**
 * 
 */
package com.pedigrees.model.domain;
import java.io.Serializable;

/**
 * @author Ishmael Thomas
 * 
 * The InitialPedigree is a class representing the
 * information for drugs manufactured by a
 * pharmaceutical manufacturer. It contains name, product, item,
 * lot, and quantity information for drugs manufactured. It carries
 * a unique serial number. It is initiated by a pharmaceutical manufacturer
 * before drug distribution. It the central domain object for
 * the first use case - Add a pedigree. 
 *
 */
public class InitialPedigree implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -6604456166837347279L;
	
	/**
	 * InitialPedigree Constructor
	 */
	public InitialPedigree(){
		
	}// end of InitialPedigree constructor
		
	/**
	 * Used to identify an initialPedigree document 
	 */
	private String serialNumber;
	
	/**
	 * Used to identify the drug potency
	 */
	private String productInfo;
	
	/**
	 * Used to identify the name of the drug 
	 */
	private String drugName;
	
	/**
	 * Used to identify the drug manufacturer 
	 */
	private String manufacturer;
	
	/**
	 * Used to identify the drug's 10 Digit - 3 Segment National Drug Code (NDC) aka UPC-A/EAN/GTIN-12 
	 */
	private String itemInfo;
	
	/**
	 * Used to identify the drug lot information 
	 */
	private String lot;
	
	/**
	 *
	 * Used to identify the quantity of the drug
	 */
	private String quantity;
	
	/**
	 * Returns the initial pedigree's serial number 
	 */
	public String getSerialNumber(){
		
		return serialNumber;
	} // end of getSerialNumber

	/**
	 * Sets the initial pedigree's serial number 
	 */
	public void setSerialNumber(String serialNumber){
	
		this.serialNumber = serialNumber;
	} // end of setSerialNumber
	
	/**
	 * Returns the drug's potency 
	 */
	public String getProductInfo() {
		
		return productInfo;
	}// end of getProductInfo
	
	/**
	 * Sets the drug's potency 
	 */
	public void setProductInfo(String productInfo){
		
		this.productInfo = productInfo;
	}// end of SetProductInfo
	
	/**
	 * Returns the name of the drug 
	 */
	public String getDrugName(){
		
		return drugName;
	}// end of getDrugName
	
	/**
	 * Sets the name of the drug 
	 */
	public void setDrugName(String drugName){
		
		this.drugName = drugName;
	}// end of setDrugName
	
	/**
	 * Returns the manufacturer of the drug 
	 */
	public String getManufacturer(){
		
		return manufacturer;
	}// end of getManufacturer
	
	/**
	 * Sets the manufacturer of the drug 
	 */
	public void setManufacturer(String manufacturer){
		
		this.manufacturer = manufacturer;
	}// end of setManufacturer
	
	/**
	 * Returns the drug's 10 Digit - 3 Segment National Drug Code (NDC) 
	 */
	public String getItemInfo(){
		
		return itemInfo;
	}// end of getItemInfo
	
	/**
	 * Sets the drug's 10 Digit - 3 Segment National Drug Code (NDC) 
	 */
	public void setItemInfo(String itemInfo){
		
		this.itemInfo = itemInfo;
	}// end of SetInfoItem
	
	/**
	 * Returns the drug's lot information 
	 */
	public String getLot(){
		
		return lot;
	}// end of getLot
	
	/**
	 * Sets the drug's lot information 
	 */
	public void setLot(String lot){
		
		this.lot = lot;
	}// end of setLot
	
	/**
	 * Returns the quantity of the drug 
	 */
	public String getQuantity(){
		
		return quantity;
	}// end of getQuantity
	
	/**
	 * Sets the quantity of the drug 
	 */
	public void setQuantity(String quantity){
		
		this.quantity = quantity;
	}// end of setQuantity
	
} // end of the InitialPedigree class
