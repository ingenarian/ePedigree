/**
 * 
 */
package com.pedigrees.model.factory;
import com.pedigrees.model.domain.Credential;
import com.pedigrees.model.domain.Manufacturer;
import com.pedigrees.model.domain.InitialPedigree;
import com.pedigrees.model.exceptions.ServiceLoadException;
import com.pedigrees.model.services.IManufacturerRegistrationDBService;
import com.pedigrees.model.services.IPedigreeDocumentDBService;
import com.pedigrees.model.services.IPedigreeLoginService;

import junit.framework.TestCase;

/**
 * @author Ish
 *
 */
public class ServiceFactoryTest extends TestCase {

	/**
	 * Test method for {@link com.pedigrees.model.factory.ServiceFactory#getService(java.lang.String)}.
	 */
	public void testGetService() {
		
		
		//Creating a Service Factory instance
		ServiceFactory serviceFactory = ServiceFactory.getInstance();
		
		// Establish process variables
		String processResults = null;
		String mName = "";
		String mUName = "";
		String mPassword = "";
		String mSignature = "";
		
		//Create a manufacturer object DTO and set the properties with input from the user
		Manufacturer manufacturer = new Manufacturer();
		manufacturer.setUsername(mName);
		manufacturer.setManufacturersname(mUName);
		manufacturer.setPassword(mPassword);
		manufacturer.setManufacturerssignature(mSignature);
		
		//Establishing a Service bond
		IManufacturerRegistrationDBService mfgRegDBSvc = null;
		try {
			
			//Returning the name of the interface object type and assigning it to an interface reference type
			mfgRegDBSvc = (IManufacturerRegistrationDBService)serviceFactory.getService(IManufacturerRegistrationDBService.NAME);
		
			//Asserts that interface object name is the same as the interface object name assigned to the interface object reference
			assertEquals("IManufacturerRegistrationDBService",mfgRegDBSvc);
			//Returning false results from interface implementation object and assigning it to a string variable
			processResults = mfgRegDBSvc.createManufacturerProfile(manufacturer);
			
			//Asserts that string variable was returned a false status from the interface implementation object.
			assertEquals("false",processResults);
		
		} catch (ServiceLoadException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}// end of Service bond
		
			
		// Establish process variables
		
		String sNumber = "";
		String pInfo = "";
		String dName = "";
		String mName1 = "";
		String iInfo = "";
		String lInfo = "";
		String qInfo = "";
		
		//Create a pedigree (initial) object DTO and set the properties with input from the user
		InitialPedigree initialPedigree = new InitialPedigree();
		initialPedigree.setSerialNumber(sNumber);
		initialPedigree.setProductInfo(pInfo);
		initialPedigree.setDrugName(dName);
		initialPedigree.setManufacturer(mName1);
		initialPedigree.setItemInfo(iInfo);
		initialPedigree.setLot(lInfo);
		initialPedigree.setQuantity(qInfo);
		
		//Establishing a Service bond
		IPedigreeDocumentDBService pedDocDBSvc = null;
		try {
			
			//Returning the name of the interface object type and assigning it to an interface reference type
			pedDocDBSvc = (IPedigreeDocumentDBService)serviceFactory.getService(IPedigreeDocumentDBService.NAME);
		
			//Asserts that interface object name is the same as the interface object name assigned to the interface object reference
			assertEquals("IPedigreeDocumentDBService", pedDocDBSvc);
		
			//Returning false results from interface implementation object and assigning it to a string variable
			processResults = pedDocDBSvc.createPedigreeDocument(initialPedigree);
		
			//Asserts that string variable was returned a false status from the interface implementation object.
			assertEquals("false", processResults);
		} catch (ServiceLoadException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}// end of Service bond
		
				
		// Establish process variables
		String name = "";
		String password = "";
		
		//Create a credential data transfer object (DTO) and setting the properties with input from the user
		Credential credential = new Credential();
		credential.setProposedUsersName(name);
		credential.setProposedUsersPassword(password);
		
		//Establishing a Service bond
		IPedigreeLoginService mfgValDBSvc = null;
		try {
			
			//Returning the name of the interface object type and assigning it to an interface reference type
			mfgValDBSvc = (IPedigreeLoginService)serviceFactory.getService(IPedigreeLoginService.NAME);
			
			//Asserts that interface object name is the same as the interface object name assigned to the interface object reference
			assertEquals("IPedigreeLoginService",mfgValDBSvc);
		
			//Returning false results from interface implementation object and assigning it to a string variable
			processResults = mfgValDBSvc.credentialsChecked(credential);

			//Asserts that string variable was returned a false status from the interface implementation object.
			assertEquals("false", processResults);
				
		
		} catch (ServiceLoadException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}// end of Service bond
		
		
		
		
		
	} // end of testGetService

}
