/**
 * 
 */
package com.pedigrees.model.factory;

import javax.naming.Context;
import javax.naming.InitialContext;

import com.pedigrees.model.factory.ServiceFactory;
import com.pedigrees.model.exceptions.ServiceLoadException;
import com.pedigrees.model.services.IService;

/**
 * @author Ishmael Thomas
 * 
 * The ServiceFactory is a factory class that takes
 * a string name of a service, creates a class equivalent of it,
 * and returns it in a class interface form.
 *
 */
public class ServiceFactory {

	public ServiceFactory() {}
	private static ServiceFactory serviceFactoryInstance;
	public static ServiceFactory getInstance() 
	{
		if (serviceFactoryInstance == null)
			serviceFactoryInstance = new ServiceFactory();		
		return serviceFactoryInstance;
	}

	@SuppressWarnings("unchecked")
	public IService getService(String serviceName) throws ServiceLoadException
	{
		
		try 
		{
		   Class c = Class.forName(getImplName(serviceName));
		  
		   return (IService)c.newInstance();
		} catch (Exception excp) 
		{
            System.out.println(serviceName);
			System.out.println("get implementation name error");
		   serviceName = serviceName + " not loaded";
		   throw new ServiceLoadException(serviceName, excp);
		}
	}
	
	/**
	 * 
	 * A private method that completes the getService call 
	 * by matching and returning the service name-to-interface/implementation
	 * defined as a environmental variable in the web.xml
	 */
    private String getImplName (String serviceName) throws Exception
	{
    	
       	Context iniCtx = new InitialContext();
        	
    	Context envCtx = (Context)iniCtx.lookup("java:comp/env");
        
    	return(String)envCtx.lookup(serviceName);
      
             
	} //end of getImplName
} // end of Service Factory Class
