package com.pedigrees.filters;
import javax.servlet.*;
import javax.servlet.http.*;


import java.io.*;
import java.util.zip.GZIPOutputStream;
/**
 * @author Ishmael Thomas
 * 
 * The PedigreeGZipFilter is a compression filter.
 * It uses GZip encoding to compress HTTP responses.
 *
 */
public class PedigreeGZipFilter implements Filter{

	private ServletContext sc;
	private FilterConfig config;
	
	//Constructing PedigreeGZipFilter class
	public PedigreeGZipFilter(){
		
	}// end of PedigreeGZipFilter construction
	
	
	public void init(FilterConfig filterConfig) throws ServletException{
		this.config = filterConfig;
		sc = config.getServletContext();
		
		//Getting PedigreeGZipFilter initialization status
		sc.log(config.getFilterName() + " is...Initialized!");
	}// end of init method
	
	public void doFilter(ServletRequest req,
			ServletResponse res,
			FilterChain fChain)
		throws IOException, ServletException {
		HttpServletRequest HttpReq = (HttpServletRequest) req;
		HttpServletResponse HttpRes = (HttpServletResponse) res;

		//Evaluating browser support
		PrintWriter out;
		if(isGzipSupported(HttpReq)){
			out = getGzipWriter(HttpRes);
			HttpRes.setHeader("Content-Encoding", "gzip");

			PedigreeGZipFilterWrapper wrapper = new PedigreeGZipFilterWrapper(HttpRes);

			fChain.doFilter(HttpReq, wrapper);
			out.print(wrapper.toString());
			out.close();
		} else {

			fChain.doFilter(HttpReq, HttpRes);
		}// end of browser evaluation

		System.out.println("Close GZIP Filter");
}// end of doFilter
	
	//Cleaning up 
	public void destroy(){
		
		//assigning null status to instance variables
		config = null;
		sc = null;
	}// end of destroy
	
	//Returning browser evaluation response
	public boolean isGzipSupported(HttpServletRequest HttpReq){
		
		String encodings = HttpReq.getHeader("Accept-Encoding");
		System.out.println("Open GZIP Filter");
		System.out.println("What data compression algorithm does the client broswer support?:");
		System.out.println(encodings);
		System.out.println("Deflate!");
		return((encodings != null) && (encodings.indexOf("gzip")!= -1));
		
	}// end of isGzipSupported method
	
	//Returning PrintWriter response
	public PrintWriter getGzipWriter(HttpServletResponse HttpRes)throws IOException{
		return(new PrintWriter(new GZIPOutputStream(HttpRes.getOutputStream())));
	}// end getGzipWriter Method
	
}// end of PedigreeGZipFilter class
