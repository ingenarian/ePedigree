package com.pedigrees.filters;

import javax.servlet.http.*;

import java.io.*;

/**
 * @author Ishmael Thomas
 * 
 * The PedigreeGZipFilterWrapper is a customized
 * response wrapper. It wraps the original
 * HTTP response object by adding a compression
 * on the servlet output stream.
 *
 */

public class PedigreeGZipFilterWrapper extends HttpServletResponseWrapper{

	StringWriter writer = new StringWriter();
	
	//Constructing PedigreeGZipFilterWrapper with an argument
	public PedigreeGZipFilterWrapper(HttpServletResponse HttpRes) {
		super(HttpRes);
	}// end of PedigreeGZipFilterWrapper construction

	public PrintWriter getWriter(){
		   return new PrintWriter(writer);
	   }// end of getWriter method
		
	   public String toString(){
		   return writer.toString();
	   }// end of toString method
	   
}// end of PedigreeGZipFilterWrapper Class
