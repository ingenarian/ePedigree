/**
 * 
 */
package com.pedigrees.filters;
import java.io.*;
import java.util.Date;

import javax.servlet.*;
import javax.servlet.http.HttpServletRequest;

//importing com.pedigrees.model.domain.Manufacturer;
import com.pedigrees.model.domain.Manufacturer;
/**
 * @author Ishmael Thomas
 * 
 * The Pedigree Login Filter is a tracking filter.
 * It captures the current manufacturer logging into
 * the application to a log.
 *
 */
//PedigreeLoginFilter implements Filter
public class PedigreeLoginFilter implements Filter{

private FilterConfig fc;
	
	//Filter set-up logic with the init method
	public void init(FilterConfig config)throws ServletException{
	
		this.fc = config;
	}// end of init method
	
	//Implementing filter logic for the PedigreeLoginFilter with the doFilter method
	public void doFilter(ServletRequest req, 
						 ServletResponse res, 
						 FilterChain chain) throws ServletException, IOException{
		
		//Entering filter
		System.out.println("********************//********************//********************//*******");
		
		//Casting the Servlet request and response to HTTP subtypes 
		HttpServletRequest httpReq = (HttpServletRequest)req;
	
		//Creating a time stamp
		Date now = new Date();
					
		//Casting httpReq object attribute into a customer reference type
		Manufacturer manufacturer = (Manufacturer) httpReq.getAttribute("manufacturer");
		
		
		//Transferring customer reference type property value into string variable 
		String username = manufacturer.getUsername();
		
				
		//Tracking current user logged into the application
		fc.getServletContext().log("Manufacturer: " + username + " logged into the ePedigree Application at: " + now);
		
		
		// next filter or servlet
		chain.doFilter(req, res);
		
		//Exiting filter
		System.out.println("********************//********************//********************//*******");
			
	}// end of doFilter method
	
	// destroying the filter
	public void destroy(){};
	
}// end of PedigreeLoginFilter Class
