package com.pedigrees.alltestsuite;

import com.pedigrees.model.manager.ManufacturerRegistrationManagerTest;
import com.pedigrees.model.manager.PedigreeDocumentManagerTest;
import com.pedigrees.model.manager.PedigreeLoginManagerTest;
import com.pedigrees.view.taghandler.PedigreeDVTagHandlerTest;

import junit.framework.Test;
import junit.framework.TestSuite;

public class AllTestSuite {

	public static Test suite() {
		TestSuite suite = new TestSuite("Test for com.pedigrees.alltestsuite");
		//$JUnit-BEGIN$
		suite.addTestSuite(ManufacturerRegistrationManagerTest.class);
		suite.addTestSuite(PedigreeDocumentManagerTest.class);
		suite.addTestSuite(PedigreeLoginManagerTest.class);
		suite.addTestSuite(PedigreeDVTagHandlerTest.class);
		//$JUnit-END$
		return suite;
	}

}
