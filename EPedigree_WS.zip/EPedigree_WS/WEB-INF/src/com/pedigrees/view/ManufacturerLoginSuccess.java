/**
 * 
 */
package com.pedigrees.view;
import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
/**
 * @author Ishmael Thomas
 * 
 * Production Model: This a view object generated when the manufacturer has
 * successfully logged-in with a valid  user name and password.
 * It is redirected from the manufacturer login
 * manager.
 *
 */
public class ManufacturerLoginSuccess extends HttpServlet{

	/**
	 * 
	 */
	private static final long serialVersionUID = 8764229123906590422L;

	public void doPost(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException
	  {
		//Processing success message with HttpServletResponse methods within a try/catch block
		res.setContentType("text/html");
		try {
			PrintWriter out = res.getWriter();
			
			out.print("<html>");
			out.print("<head><title>Manufacturer Login Status:</title></head>");
			out.print("<body>");
			out.print("<h1>Login Succeeded!</h1>");
			out.print("</body>");
			out.print("</html>");
			
		} catch (IOException e) {
			e.printStackTrace();
		}// end of try/catch block
	 } // end of doPost method
}// end of ManufacturerLoginSucces
