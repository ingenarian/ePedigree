/**
 * 
 */
package com.pedigrees.view.taghandler;

import junit.framework.TestCase;

/**
 * @author Ish
 *
 */
public class PedigreeDVTagHandlerTest extends TestCase {

	/**
	 * Test method for {@link com.pedigrees.view.taghandler.PedigreeDVTagHandler#doTag()}.
	 */
	public void testDoTag() {
			
		
		//The doTag method calls the getComment to get the comment string as input for JSP response page
		String JspReponseInput = getComment();
		
		//Test the string input from the getComment method with a false string input.
		//The assert is that both strings are not the same
		assertNotSame("Hello, this is a test page",JspReponseInput);
		
	} // end of the testDoTag method

	//Called by the doTag method to return a string input for a JSP response page
	private String getComment() {
		
		//The correct string input for the JSP response page
		String comment = "Hello, this pedigree is registered in the epedigree database as:   ";
		return comment;
	}// end of the getComment method


}
