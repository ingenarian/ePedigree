/**
 * 
 */
package com.pedigrees.view.taghandler;
import javax.servlet.jsp.JspException;
import javax.servlet.jsp.tagext.SimpleTagSupport;
import java.io.IOException;
/**
 * @author Ishmael Thomas
 * It is a customized tag for retrieving and viewing pedigree
 * information from the epedigree database. It extends
 * SimpleTag Support.
 *
 */
public class PedigreeDVTagHandler extends SimpleTagSupport{

//String attribute variable
private String user;
	
	//The doTag method is called by Container when invoked by pedigreeDVIndex.jsp
	public void doTag() throws JspException, IOException {
		getJspContext().getOut().write(user + getComment());
	}// end of doTag method
	
	//Called by the Container to set the value from the tag attribute
	public void setUser(String user){
		this.user = user;
	}// end of setAnalysis
	
	//Called from within the doTag method to be process as part of the pedigreeDVResponse.jsp
	String getComment(){
		String comment = "Hello, this initial pedigree is registered in the epedigree database as:   ";
		return comment;
	}// end of getComment

} // end of PedigreeDVTagHandler
