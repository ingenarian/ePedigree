/**
 * 
 */
package com.pedigrees.view;
import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
/**
 * @author Ishmael Thomas
 * 
 * Production Model: This a view object generated when the manufacturer has
 * failed to create a pedigree document because they did not fill-in all data fields
 * as specified on HTML form.
 * It is redirected from the Pedigree Document Creation  Manager.
 *
 */
public class PedigreeDocCreationError extends HttpServlet{

	/**
	 * 
	 */
	private static final long serialVersionUID = -3187672952267606589L;
	
	public void doPost(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException
	  {
		//Processing success message with HttpServletResponse methods within a try/catch block
		res.setContentType("text/html");
		try {
			PrintWriter out = res.getWriter();
			
			out.print("<html>");
			out.print("<head><title>Pedigree Document Creation Status:</title></head>");
			out.print("<body>");
			out.print("<h1>Creation Failed!</h1>");
			out.print("</body>");
			out.print("</html>");
			
		} catch (IOException e) {
			e.printStackTrace();
		}// end of try/catch block
	 } // end of doPost method

}// end of PedigreeDocCreationError Class
