/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.pedigrees.model.managers;

import com.pedigrees.model.domain.AdvancedShippingNotices;
import com.pedigrees.model.domain.Containers;
import com.pedigrees.model.domain.Invoices;
import com.pedigrees.model.domain.Pedigrees;
import javax.annotation.sql.DataSourceDefinition;
import javax.ejb.embeddable.EJBContainer;
import javax.naming.Context;
import javax.naming.NamingException;
//import org.junit.Assert;
//import org.junit.Test;

/**
 *
 * @author Ish
 */
@DataSourceDefinition(
        name="java:jdbc/pedigree",
        className="com.mysql.jdbc.jdbc2.optional.MysqlDataSource",
        user="root", 
        password="admin",
        databaseName="pedigree",
        serverName="localhost",
        portNumber=3306)
public class PedigreeMgrBeanTest {
    
    public PedigreeMgrBeanTest() {
    }// end of constructor
   
    /**
     * Test of create method, of class PedigreeMgrBean.
     * 
     * 
     */
    
    // Uncomment for individual testing
    ///*
  // @Test
    public void testCreate() {
     try{ 
       EJBContainer ec0 = EJBContainer.createEJBContainer();
       Context ctx = ec0.getContext();
       PedigreeManager pm0 = (PedigreeManager)
       ctx.lookup("java:global/classes/PedigreeMgrBean!com.pedigrees.model.managers.PedigreeManager");
      
       //New instance of a test Advanced Shipping Notice
      AdvancedShippingNotices testASN = new AdvancedShippingNotices();
      testASN.setSentToReceiverStatus("Sent Test");

      //New instance of a test Container with allocated goods 
       Containers testContainer = new Containers();
       testContainer.setContainersTransmittedStatus("Test Enroute");
       testContainer.setGoodsAllocatedStatus("Test Allocated");
       
      //New instance of a test Invoice to the Distributor 
       Invoices testInvoice = new Invoices();
       testInvoice.setReceiverPaidInvoiceStatus("Test Paid");
      
      //New instance of a test Pedigree
       Pedigrees testPedigree = new Pedigrees();
       testPedigree.setId(4);
       testPedigree.setSerialNumber("Q");
       testPedigree.setPedigreeDate("081813");
       
       //Specify a system of record (SOR) for the test Pedigree
       testPedigree.setASN(testASN);
       testPedigree.setContainer(testContainer);
       testPedigree.setInvoice(testInvoice);
       
       //Create an assertion for the test Pedigree
       testPedigree = pm0.create(testPedigree);
      // Assert.assertNotNull(testPedigree);
       ec0.close();
       }catch (NamingException ex){
      //  Assert.fail("testPedigree is null, JNDI Global Lookup name failed!");
      }// end of try/catch block
    }// end of testCreate Method
   // */
    // Uncomment for individual testing
   
    /**
     * Test of read method, of class PedigreeMgrBean.
     * 
     * 
     */
  /* 
  @Test
   public void testRead(){
     try{
       EJBContainer ec2 = EJBContainer.createEJBContainer();
       Context ctx = ec2.getContext();
       PedigreeManager pm2 = (PedigreeManager)
       ctx.lookup("java:global/classes/PedigreeMgrBean!com.pedigrees.model.managers.PedigreeManager");
       
       //Make assertion on Pedigrees table id 4
       Pedigrees testReadPed = new Pedigrees();
       Pedigrees testPed = new Pedigrees();
       int validID;
       String validatedValue;
       pm2.delete(testPed);
       pm2.create(testReadPed);
       testReadPed = pm2.read(1);
       validID = testReadPed.getId();
       validatedValue = Integer.toString(validID);
       Assert.assertNotNull(validatedValue);
       ec2.close();
     } catch(NamingException ex){
         Assert.fail("Pedigrees table id 1 not read, JNDI Global lookup name failed!");
       } // end of try/catch block
   }// end of testRead Method
  */
    
    // Uncomment for individual testing
    
     /**
     * Test of update method, of class PedigreeMgrBean.
     * 
     * 
     */
  /*
  @Test
   public void testUpdate(){
     try{
       EJBContainer ec3 = EJBContainer.createEJBContainer();
       Context ctx = ec3.getContext();
       PedigreeManager pm3 = (PedigreeManager)
       ctx.lookup("java:global/classes/PedigreeMgrBean!com.pedigrees.model.managers.PedigreeManager");
       //New instance of a test Pedigree
       Pedigrees updateTestPedigree = new Pedigrees();
       Pedigrees newUpdatedPedigree = new Pedigrees();
       updateTestPedigree.setId(2);
       updateTestPedigree.setSerialNumber("U");
       updateTestPedigree.setPedigreeDate("081913");
       pm3.update(updateTestPedigree);
       newUpdatedPedigree = updateTestPedigree;
       Assert.assertNotNull(newUpdatedPedigree);
       ec3.close();
     } catch(NamingException ex){
         Assert.fail("Pedigrees table not updated, JNDI Global lookup name failed!");
       } // end of try/catch block
   }// end of testUpdate Method
   */
    
    // Uncomment for individual testing
    
    /**
     * Test of delete method, of class PedigreeMgrBean.
     * 
     *      
     */
  /* 
   @Test
   public void testDelete(){
     try{
       EJBContainer ec4 = EJBContainer.createEJBContainer();
       Context ctx = ec4.getContext();
       PedigreeManager pm4 = (PedigreeManager)
       ctx.lookup("java:global/classes/PedigreeMgrBean!com.pedigrees.model.managers.PedigreeManager");
        
       //New instance of  delete Pedigrees
       Pedigrees delPed = new Pedigrees();
       Pedigrees testPed = new Pedigrees();
       pm4.delete(delPed);
       testPed.setId(1);
       Assert.assertNotSame(testPed, delPed);
       ec4.close();
     } catch(NamingException ex){
         Assert.fail("delPed is not null, JNDI Global lookup name failed!");
       } // end of try/catch block
   }// end of testDelete Method
    */
        // Uncomment for individual testing
    
}// end of PedigreeMgrBeanTest