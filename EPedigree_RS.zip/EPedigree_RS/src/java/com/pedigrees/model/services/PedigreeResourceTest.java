/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.pedigrees.model.services;
import com.pedigrees.model.managers.PedigreeManager;
import com.pedigrees.model.domain.AdvancedShippingNotices;
import com.pedigrees.model.domain.Containers;
import com.pedigrees.model.domain.Invoices;
import com.pedigrees.model.domain.Pedigrees;
import java.io.IOException;
import javax.enterprise.context.RequestScoped;
import javax.inject.Inject;
import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.FormParam;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.xml.bind.JAXBElement;

/**
 *
 * @author Ish
 * 
 * The PedigreeResourceTest Class is designed to 
 * test to the RESTful operation requests
 * as delegated by the Pedigree Manager -
 * POST(createe), GET(read), PUT(update), and 
 * DELETE (remove). It will executed on 
 * the Pedigree entity and associated relationships.
 */
@Path("testpedigree")
@RequestScoped
public class PedigreeResourceTest {
    @Inject
    private PedigreeManager mgr;
    
    //RESTful operation request tests go here 
    
}// end of PedigreeResourceTest Class
