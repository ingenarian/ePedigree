/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.pedigrees.model.services;

import com.pedigrees.model.managers.PedigreeManager;
import com.pedigrees.model.exceptions.PedigreeReadResourceException;
import javax.enterprise.context.RequestScoped;
import javax.ejb.EJB;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

/**
 *
 * @author Ish
 * 
 *  The PedigreeCreateResource Class is designed to 
 * execute to the RESTful operation request
 * as delegated by the Pedigree Manager -
 * GET (Read). It will executed on the Pedigree entity
 * and associated relationships.
 */

//CONTENT NEGOTIATION - URL
@Path("selectivepedigree/{id}.xml")
@RequestScoped
public class PedigreeReadResource {
    @EJB
    private PedigreeManager mgr;

       //Reading a Pedigree Record
    @GET
    public Response getPedigree(@PathParam("id")int id) throws PedigreeReadResourceException{
       
        Response.ResponseBuilder builder = Response.ok(mgr.read(id)).type(MediaType.APPLICATION_XML_TYPE);
       
        return builder.build();
    }//end of Response getPedigree method
    
}// end of PedigreeReadResource Class
