/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.pedigrees.model.services;

import com.pedigrees.model.domain.Pedigrees;
import com.pedigrees.model.managers.PedigreeManager;
import com.pedigrees.model.exceptions.PedigreeUpdateResourceException;
import javax.enterprise.context.RequestScoped;
import javax.ejb.EJB;
import javax.ws.rs.Consumes;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

/**
 *
 * @author Ish
 * 
 * The PedigreeCreateResource Class is designed to 
 * execute to the RESTful operation request
 * as delegated by the Pedigree Manager -
 * PUT (Update). It will executed on the Pedigree entity
 * and associated relationships.
 * 
 */
//CONTENT NEGOTIATION - ACCEPT HEADER
@Path("currentpedigree")
@RequestScoped
public class PedigreeUpdateResource {
    
  @EJB
  private PedigreeManager mgr;
    
  //Updating a Pedigree Record
 @PUT
 
 @Consumes({MediaType.APPLICATION_XML})
 public Response updatePedigee() throws PedigreeUpdateResourceException{
   Pedigrees mfgrPedigree = new Pedigrees();
    mfgrPedigree.setPedigreeDate("080813");                    
    
    mfgrPedigree = mgr.update(mfgrPedigree);
    
    Response.ResponseBuilder builder = Response.ok(mfgrPedigree);
    return builder.build();
  }//end of Response updatePedigree
    
}// end of PedigreeUpdateResource
