/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.pedigrees.model.services;

import com.pedigrees.model.domain.Pedigrees;
import com.pedigrees.model.managers.PedigreeManager;
import com.pedigrees.model.exceptions.PedigreeDeleteResourceException;
import javax.enterprise.context.RequestScoped;
import javax.ejb.EJB;
import javax.ws.rs.DELETE;
import javax.ws.rs.Path;


/**
 *
 * @author Ish
 * The PedigreeCreateResource Class is designed to 
 * execute to the RESTful operation request
 * as delegated by the Pedigree Manager -
 * DELETE (remove). It will executed on the Pedigree entity
 * and associated relationships.
 */

//CONTENT NEGOTIATION - URL
@Path("oldpedigree")
@RequestScoped
public class PedigreeDeleteResource {
    @EJB
    private PedigreeManager mgr;
    
     @DELETE
   //  @Produces({MediaType.APPLICATION_XML})
     public void deletePedigree() throws PedigreeDeleteResourceException{
       Pedigrees mfgrPedigree = new Pedigrees();
       mgr.delete(mfgrPedigree);
       
     }//end of deletePedigree
}// end of PedigreeDeleteResource Class
