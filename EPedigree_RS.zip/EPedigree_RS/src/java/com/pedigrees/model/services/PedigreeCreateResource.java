/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.pedigrees.model.services;

import com.pedigrees.model.domain.AdvancedShippingNotices;
import com.pedigrees.model.domain.Containers;
import com.pedigrees.model.domain.Invoices;
import com.pedigrees.model.domain.Pedigrees;
import com.pedigrees.model.managers.PedigreeManager;
import com.pedigrees.model.exceptions.PedigreeCreateResourceException;
import javax.enterprise.context.RequestScoped;
import javax.ejb.EJB;
import javax.ws.rs.Consumes;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

/**
 *
 * @author Ish
 * 
 * The PedigreeCreateResource Class is designed to 
 * execute to the RESTful operation request
 * as delegated by the Pedigree Manager -
 * POST (Create). It will executed on the Pedigree entity
 * and associated relationships.
 */

//CONTENT NEGOTIATION - ACCEPT HEADER
@Path("newpedigree")
@RequestScoped
public class PedigreeCreateResource {

   
    @EJB
    private PedigreeManager mgr;

    //Creating an Pedigree Record
    @POST
    @Produces("application/xml")
    @Consumes({MediaType.APPLICATION_XML})
    public Response createPedigree() throws PedigreeCreateResourceException{
    
     //New instance of a Manufacturer's Advanced Shipping Notice
      AdvancedShippingNotices mfgrASN = new AdvancedShippingNotices();
      mfgrASN.setSentToReceiverStatus("Sent");

      //New instance of a Manufacturer's Transmitted Container with allocated goods 
       Containers mfgrContainer = new Containers();
       mfgrContainer.setContainersTransmittedStatus("Enroute");
       mfgrContainer.setGoodsAllocatedStatus("Allocated");
       
      //New instance of a Manufacturer's Invoice to the Distributor 
       Invoices mfgrInvoice = new Invoices();
       mfgrInvoice.setReceiverPaidInvoiceStatus("Paid");
      
      //New instance of a Manufacturer's Pedigree
       Pedigrees mfgrPedigree = new Pedigrees();
       mfgrPedigree.setId(1);
       mfgrPedigree.setSerialNumber("Z");
       mfgrPedigree.setPedigreeDate("080313");
        //Specify a system of record (SOR) for the Manufacturer's Pedigree
       mfgrPedigree.setASN(mfgrASN);
       mfgrPedigree.setContainer(mfgrContainer);
       mfgrPedigree.setInvoice(mfgrInvoice);
       
       //Create the SOR for the Manufacturer's Pedigree
       mfgrPedigree = mgr.create(mfgrPedigree);
      
       Response.ResponseBuilder builder = Response.ok(mfgrPedigree);
      
         return builder.build();
           
    }// end of createPedigree Method
    
}// end of PedigreeCreateResource Class
