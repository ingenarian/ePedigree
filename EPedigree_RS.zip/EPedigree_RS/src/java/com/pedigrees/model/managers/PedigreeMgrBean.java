/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.pedigrees.model.managers;
import com.pedigrees.model.domain.Pedigrees;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

/**
 *
 * @author Ish
 * 
 * The Pedigree Manager Bean fulfills the pedigree
 * CRUD operations specified by the Pedigree
 * Manager Interface
 * 
 */

@Stateless
public class PedigreeMgrBean implements PedigreeManager{
  @PersistenceContext(unitName ="pedigree")
  EntityManager em;
      
    @Override
    public Pedigrees create(Pedigrees ped){
      em.persist(ped);
      return ped;
    }// end of Pedigrees create method
    
    @Override
    public Pedigrees read(int id) {
      Pedigrees ped = null;
      em.find(Pedigrees.class, id);
      return ped;
    }// end of Pedigrees read method
    
    @Override
    public Pedigrees update(Pedigrees ped) {
      em.merge(ped);
      return ped;
   }// end of Pedigrees update method
        
    @Override
    public void delete(Pedigrees ped) {
      em.remove(ped);
      
    }// end of Pedigree delete method
    
}// end of PedigreeMgrBean Class