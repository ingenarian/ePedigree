/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.pedigrees.model.managers;
import com.pedigrees.model.domain.Pedigrees;

/**
 *
 * @author Ish
 * The Pedigree Manager is an interface that provides a contract for 
 * pedigree CRUD operations delivered by the pedigree manager 
 * implementation.
 */
public interface PedigreeManager {
    
    public Pedigrees create(Pedigrees ped);
    public Pedigrees read(int id);
    public Pedigrees update(Pedigrees ped);
    public void delete(Pedigrees ped);
    
}// end of PedigreeManager Class
