/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.pedigrees.model.exceptions;
import java.io.Serializable;
/**
 *
 * @author Ish
 * 
 * PedigreeReadResourceException class is a custom checked exception.
 * It is designed for try/catch operations for the JAX-RS PedgireeReadResource.
 */
public class PedigreeReadResourceException extends Exception implements Serializable {
    
    public PedigreeReadResourceException(){
        super();
    }// end of no argument PedigreeReadResourceException Constructor
    
    public PedigreeReadResourceException(String msg){
        super(msg);
    }// end of one argument PedigreeReadResourceException Constructor
    
    public PedigreeReadResourceException(String msg, Exception e){
        super(msg, e);
    }// end of two argument PedigreeReadResourceException Constructor
    
}// end of PedigreeReadResourceException Class
