/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.pedigrees.model.exceptions;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;
import javax.ws.rs.ext.Provider;
import javax.ws.rs.ext.ExceptionMapper;

/**
 *
 * @author Ish
 * The PedigreeReadResourceExceptionHandler class
 * implements the ExceptionMapper for a PedigreeReadResourceException type
 */
@Provider
public class PedigreeReadResourceExceptionHandler implements ExceptionMapper<PedigreeReadResourceException> {

    @Override
    public Response toResponse(PedigreeReadResourceException exception) {
        return Response.status(Status.SERVICE_UNAVAILABLE).entity(exception.getMessage()).build();
    }// end of toResponse Method
    
}// end of PedigreeReadResourceExceptionHandler Class
