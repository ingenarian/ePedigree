/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.pedigrees.model.exceptions;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;
import javax.ws.rs.ext.Provider;
import javax.ws.rs.ext.ExceptionMapper;
/**
 *
 * @author Ish
 * The PedigreeUpdateResourceExceptionHandler class
 * implements the ExceptionMapper for a PedigreeUpdateResourceException type
 */
@Provider
public class PedigreeUpdateResourceExceptionHandler implements ExceptionMapper<PedigreeUpdateResourceException> {

    @Override
    public Response toResponse(PedigreeUpdateResourceException exception) {
        return Response.status(Status.SERVICE_UNAVAILABLE).entity(exception.getMessage()).build();
    }// end of toResponse Method
    
}// end of PedigreeUpdateResourceExceptionHandler Class
