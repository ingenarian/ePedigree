/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.pedigrees.model.exceptions;
import java.io.Serializable;

/**
 *
 * @author Ish
 * 
 * PedigreeUpdateResourceException class is a custom checked exception.
 * It is designed for try/catch operations for the JAX-RS PedgireeUpdateResource.
 */
public class PedigreeUpdateResourceException extends Exception implements Serializable{
    
     public PedigreeUpdateResourceException(){
        super();
    }// end of no argument PedigreeUpdateResourceException Constructor.
     
    public PedigreeUpdateResourceException(String msg){
        super(msg);
    }// end of one argument PedigreeUpdateResourceException Constructor.
    
    public PedigreeUpdateResourceException(String msg, Exception e){
        super(msg, e);
    }// end of two argument PedigreeUpdateResourceException Constructor.
    
}// end of PedigreeUpdateResourceException Class
