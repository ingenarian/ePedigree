/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.pedigrees.model.exceptions;
import java.io.Serializable;
/**
 *
 * @author Ish
 * 
 * PedigreeDeleteResourceException class is a custom checked exception.
 * It is designed for try/catch operations for the JAX-RS PedgireeDeleteResource.
 */
public class PedigreeDeleteResourceException extends Exception implements Serializable {
    
     public PedigreeDeleteResourceException(){
        super();
    }// end of no argument PedigreeDeleteResourceException Constructor
     
    public PedigreeDeleteResourceException(String msg){
        super(msg);
    }// end of one argument PedigreeDeleteResourceException Constructor
    
    public PedigreeDeleteResourceException(String msg, Exception e){
        super(msg, e);
    }// end of two argument PedigreeDeleteResourceException Constructor.
    
}// end of PedigreeDeleteResourceException Class
