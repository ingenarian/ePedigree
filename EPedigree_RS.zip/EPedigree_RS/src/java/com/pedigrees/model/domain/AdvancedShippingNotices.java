/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.pedigrees.model.domain;
import java.io.Serializable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author Ish
 * 
 * The AdvanceShippingNotices class
 * is a blueprint for object types using
 * properties and behaviors from this class
 */
@XmlRootElement(name = "AdvancedShippingNotices")
@Entity
@Table(name = "ADVANCEDSHIPPINGNOTICE")
public class AdvancedShippingNotices implements Serializable{
    
      /**
      * Primary key property for a Pedigree
      */
    private int id;
    
    /**
     * Unique property status for AdvancedShippingNotices sent 
     * 
     */
    private String sentToReceiver;
    
   
    /**
     * Unique property status for AdvancedShippingNotices not sent
     * 
     */
     private String receivedFromShipper;
   
       
    /**
     * AdvancedShippingNotices Constructor - no argument
     * 
     */
    public AdvancedShippingNotices(){
        
    } // end of AdvancedShippingNotices Constructor-no argument
   
    /**
     * Returns a primary key information
     */
    @Id
    @GeneratedValue 
    @Column(name = "id")
    public int getId(){
        
        return id;
    }// end of getId method
    
    /**
     * Generates a primary key information
     */
    public void setId(int id){
        
        this.id = id;
    }// end of setId method
    
    /**
     * String get method for sentToReceiver
     * 
     */
    @Column(name = "sentToReceiverStatus")
  public String getSentToReceiverStatus(){
	
    return sentToReceiver;
  }// end of getSentToReceiverStatus method
   
      /**
       * String set method for sentToReceiver
       * 
       */
   public void setSentToReceiverStatus(String sentToReceiver){

    this.sentToReceiver = sentToReceiver;
  }// end of setSentToReceiverStatus method        
   
   /**
    * String get method for ReceivedFromShipper
    * 
    */
   @Column(name = "receivedFromShipperStatus")
   public String getReceivedFromShipperStatus(){

        return receivedFromShipper;
    }// end of getReceivedFromShipper method
  
    /**
     * String set method for ReceivedFromShipper
     * 
     */
   public void setReceivedFromShipperStatus(String receivedFromShipper){
 
     this.receivedFromShipper = receivedFromShipper;
    }// end of setReceivedFromShipper method
   
}// end of AdvanceShippingNotices Class
