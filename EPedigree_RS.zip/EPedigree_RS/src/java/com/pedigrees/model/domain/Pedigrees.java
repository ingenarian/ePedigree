/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.pedigrees.model.domain;
import java.io.Serializable;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlRootElement;
/**
 *
 * @author Ish
 * 
 * The Pedigree class acts as a system of record for Advanced Shipping Notices, 
 * Containers, Invoices,and Purchase Orders. It works with the Pedigree Manager (entity manager) to 
 * persist this information into the EPCIS database.
 */
@XmlRootElement(name = "Pedigrees")
@Entity
@Table(name = "PEDIGREES")
public class Pedigrees implements Serializable{
    
    /**
      * Primary key property for a Pedigree
      */
    private int id;
    
    /**
      * Identification number for a Pedigree instance
      */
   private String serialNumber;
    
    /**
     * Date stamp for a Pedigree instance
     */
    private String pedigreeDate;
           
    /**
     * Reference variable for Advanced Shipping Notices 
     * Establishes a one to one relationship with a Pedigree (uni-directional)
     * 
     */
    private AdvancedShippingNotices asn;
       
    /**
     * Reference variable for Containers 
     * Establishes a one to one relationship with a Pedigree (uni-directional)
     * 
     */
    private Containers container;
    
    /**
     * Reference variable for Invoices 
     * Establishes a one to one relationship with a Pedigree (uni-directional)
     * 
     */
    private Invoices invoice;
    
     /**
     * Pedigree Constructor - no argument
     */
    public Pedigrees(){
    }// end of Pedigre Constructor - no argument
    
    /**
     * Returns a primary key information
     */
    @Id
    @GeneratedValue 
    @Column(name = "id")
    public int getId(){
        
        return id;
    }// end of getId method
    
    /**
     * Generates a primary key information
     */
    public void setId(int id){
        
        this.id = id;
    }// end of setId method
    
    /**
     * Returns a pedigree serial number
     */
   @Column(name = "serialNumber")
    public String getSerialNumber(){
        
        return serialNumber;
    }// end of getSerialNumber method
    
    /**
     * Sets a pedigree serial number
     */
    public void setSerialNumber(String serialNumber){
        
        this.serialNumber = serialNumber;
    }// end of setSerialNumber method
    
    /**
     * Returns a pedigree date stamp
     */
   @Column(name = "pedigreeDate")
    public String getPedigreeDate(){
        
        return pedigreeDate;
    }// end of getPedigreeDate method
    
    /**
     * Sets a pedigree date stamp
     */
    public void setPedigreeDate(String pedigreeDate){
        
        this.pedigreeDate = pedigreeDate;
    }// end of setPedigreeDate method
        
    /**
     * Get method for  AdvancedShippingNotices
     * 
     */
    @JoinColumn(name = "asn")
    @OneToOne(cascade  = {CascadeType.ALL}) //One ASN to one Pedigree
    public AdvancedShippingNotices getASN(){
        
        return  asn;
    }// end of getASN method 
    
    /**
     * Set method for AdvancedShippingNotices
     *  
     */
    public void setASN(AdvancedShippingNotices asn){
        
        this.asn = asn;
    }// end of setASN method
    
    /**
     * Get method for Containers
     * 
     */
   @JoinColumn(name = "container")
    @OneToOne(cascade  = {CascadeType.ALL}) // One Container to one Pedigree
    public Containers getContainer(){
        
        return  container;
    }// end of getContainer method 

    /**
     * Set method for Containers
     * 
     */
    public void setContainer(Containers container){
        
        this.container = container;
    }// end of setContainer method
    
    /**
     * Get method for Invoices
     *  
     */
    @JoinColumn(name = "invoice")
    @OneToOne(cascade  = {CascadeType.ALL}) // One Invoice to one Pedigree
    public Invoices getInvoice(){
        
        return  invoice;
    }// end of getInvoice method

    /**
     * Set method for invoices
     *  
     */
    public void setInvoice(Invoices invoice){
        
        this.invoice = invoice;
    }// end of setInvoice method
        
}// end of Pedigrees Class
