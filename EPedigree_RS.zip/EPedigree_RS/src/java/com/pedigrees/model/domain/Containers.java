/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.pedigrees.model.domain;
import java.io.Serializable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlRootElement;
/**
 *
 * @author Ish
 * 
 * The Containers class
 * is a blueprint for object types using
 * properties and behaviors from this class
 * 
 */
@XmlRootElement(name = "Containers")
@Entity
@Table(name = "CONTAINERS")
public class Containers implements Serializable {
    
     /**
      * Primary key property for a Pedigree
      */
    private int id;
    
    
 /**
 * Unique property status for Containers transmitted
 * 
 */
  private String containersTransmitted;
  
  
/**
 * Unique property status for Containers received
 * 
 */
  private String containersReceived;
  
/**
 * Unique property status for goods allocated
 * 
 */
  private String goodsAllocated;

/**
 * Unique property status for goods allocated
 * 
 */
  private String goodsReleased;
  
  
/**
 * Containers constructor - no argument
 * 
 */
  public Containers(){
      
  }// end of Containers constructor - no argument
  
  /**
     * Returns a primary key information
     */
    @Id
    @GeneratedValue 
    @Column(name = "id")
    public int getId(){
        
        return id;
    }// end of getId method
    
    /**
     * Generates a primary key information
     */
    public void setId(int id){
        
        this.id = id;
    }// end of setId method
    
/**
 * String get method for container transmitted
 * 
 */
 @Column(name = "containersTransmittedStatus")   
 public String getContainersTransmittedStatus(){
   
   return containersTransmitted;
 }// end of getContainersTransmittedStatus
  
/**
 * String set method for container transmitted
 * 
 */
  public void setContainersTransmittedStatus(String containersTransmitted){

  this.containersTransmitted = containersTransmitted;
 }// end of setContainersTransmittedStatus method
  
/**
 * String get method for container received
 * 
 */
  @Column(name = "containersReceivedStatus")
  public String getContainersReceivedStatus(){

   return containersReceived;
 }// end of getContainersReceivedStatus method
  
/**
 * String set method for container received
 * 
 */
  public void setContainersReceivedStatus(String containersReceived){

   this.containersReceived = containersReceived;
 }// end of setContainersReleasedStatus method
  
/**
 * String get method for goods allocated
 * 
 */
  @Column(name = "goodsAllocatedStatus")
  public String getGoodsAllocatedStatus(){
   
   return goodsAllocated;
 }// end of getGoodsAllocatedStatus method
  
/**
 * String set method for goods allocated
 * 
 */
  public void setGoodsAllocatedStatus(String goodsAllocated){

  this.goodsAllocated = goodsAllocated;
 }// end of setGoodsAllocategdStatus method
  
/**
 * String get method for goods released
 * 
 */
  @Column(name = "goodsReleasedStatus")
  public String getGoodsReleasedStatus(){

   return goodsReleased;
 }// end of getGoodsReleasedStatus method
  
/**
 * String set method for goods released
 * 
 */
  public void setGoodsReleasedStatus(String goodsReleased){

   this.goodsReleased = goodsReleased;
 }// end of setGoodsReleasedStatus method
    
}// end of Containers Class

