/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.pedigrees.model.domain;
import java.io.Serializable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlRootElement;
/**
 *
 * @author Ish
 * 
 * The Invoices class is a blueprint for object types using
 * properties and behaviors from this class.
 */
@XmlRootElement(name = "Invoices")
@Entity
@Table(name = "INVOICES")
public class Invoices implements Serializable{
    
    /**
      * Primary key property for a Pedigree
      */
    private int id;
    
/**
 * Unique property status for Invoices paid 
 * 
 */
 private String receiverPaidInvoice;
 
 
/**
 * Invoices constructor - no argument
 * 
 */
  public Invoices (){
      
  }// end of Inovices constructor - no argument
    
    /**
     * Returns a primary key information
     */
    @Id
    @GeneratedValue 
    @Column(name = "id")
    public int getId(){
        
        return id;
    }// end of getId method
    
    /**
     * Generates a primary key information
     */
    public void setId(int id){
        
        this.id = id;
    }// end of setId method
       
/**
 * String get method for Invoices paid 
 * 
 */
    @Column(name = "receiverPaidInvoiceStatus")
  public String getReceiverPaidInvoiceStatus(){
 
 return receiverPaidInvoice;
 }// end of getReceiverPaidInvoiceStatus method
  
/**
 * String set method for Invoices paid
 * 
 */
public void setReceiverPaidInvoiceStatus(String receiverPaidInvoice){
  
  this.receiverPaidInvoice = receiverPaidInvoice;
 }// end of setReceiverPaidInvoiceStatus method
    
}//end of Inovices Class
