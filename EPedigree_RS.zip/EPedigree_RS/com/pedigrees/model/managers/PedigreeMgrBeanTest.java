/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.pedigrees.model.managers;

import com.pedigrees.model.domain.Pedigrees;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author Ish
 */
public class PedigreeMgrBeanTest {
    
    public PedigreeMgrBeanTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of create method, of class PedigreeMgrBean.
     */
    @Test
    public void testCreate() throws Exception {
        System.out.println("create");
        Pedigrees ped = null;
        PedigreeMgrBean instance = new PedigreeMgrBean();
        Pedigrees expResult = null;
        Pedigrees result = instance.create(ped);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of read method, of class PedigreeMgrBean.
     */
    @Test
    public void testRead() throws Exception {
        System.out.println("read");
        int id = 0;
        PedigreeMgrBean instance = new PedigreeMgrBean();
        Pedigrees expResult = null;
        Pedigrees result = instance.read(id);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of update method, of class PedigreeMgrBean.
     */
    @Test
    public void testUpdate() throws Exception {
        System.out.println("update");
        Pedigrees ped = null;
        PedigreeMgrBean instance = new PedigreeMgrBean();
        Pedigrees expResult = null;
        Pedigrees result = instance.update(ped);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of delete method, of class PedigreeMgrBean.
     */
    @Test
    public void testDelete() throws Exception {
        System.out.println("delete");
        Pedigrees ped = null;
        PedigreeMgrBean instance = new PedigreeMgrBean();
        instance.delete(ped);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }
}