package com.pedigrees.model.services.emailservice;
import com.pedigrees.model.services.networkservice.NetworkServer;
import com.pedigrees.model.services.jdbcservice.JDBCServer;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import java.io.*;
import java.net.*;
import javax.swing.JOptionPane;
import com.pedigrees.model.domain.Envelope;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import com.pedigrees.model.services.logservice.LogServer;
import org.apache.log4j.PropertyConfigurator;
import org.apache.log4j.Logger;
/**
 * The EmailServer is an interface for the epedigree controller on the client-side.
 * 
 * @author Ish
 */
public class EmailServer {
	
	
    
    public static void main(String[] args )
	{
		int i = 1;
		
		try
		{
                   
                   String thisLog;
                   @SuppressWarnings("unused")
                   String thisIP;
		           String thisPort;
		           int thisConvertedPort;
		
		ApplicationContext context = new ClassPathXmlApplicationContext(
		"applicationContext.xml");
		
		LogServer logServer = (LogServer)context.getBean("logCfg");
		thisLog = logServer.getPropFile("log");
		// Initialize Properties for components
		PropertyConfigurator.configure(thisLog);
		System.out.println("Successfully configured log4j");
	
		
		NetworkServer networkServer = (NetworkServer)context.getBean("netCfg");
		thisPort = networkServer.getPort("port");
		thisConvertedPort = Integer.parseInt(thisPort);
		thisIP = networkServer.getIP("IP");
	 		
			// Step 1: Create a ServerSocket
		    ServerSocket s = new ServerSocket(thisConvertedPort);
		    // Step 2: Wait for a connection from a client
		    System.out.print("Server is ready. Awaiting Connections");
		    // Step 3: Spawn Email Server Thread
		    for (;;)
		    {
		    	Socket incoming = s.accept( ); 
		    	System.out.println("Spawning Thread " + i);
		    	new ThreadedEmailServer(incoming, i).start();
		    	i++;
		    }
		} catch (Exception e){
			System.out.println(e);
		}
	} // end of main method
} // end of EmailServer	

		
class ThreadedEmailServer extends Thread {
	
     String engineState = null;

     Socket incoming;
     int counter;
     ThreadedEmailServer(Socket i, int c){

     incoming = i;
     counter = c;
    } // end of ThreadedEmailServer constructor

public void run(){

    String statusMessage = null;

    try
    {
    // Create input and output streams
     ObjectInputStream in = new ObjectInputStream(incoming.getInputStream());
     ObjectOutputStream out = new ObjectOutputStream(incoming.getOutputStream());

     //output message on the client console
     out.writeObject( "Server >> Ready to process your request! \r" );

     // Process connection
     boolean done = false;
     while (!done)	
     {
        String str = (String)in.readObject();
        if (str == null) done = true;
        else
        {
        //display client's message
        	log.info(str);

        // start email engine to send mail
             statusMessage =  getEngineStarted();
             log.info(statusMessage);
  
        } // end if/else

        // evaluate status message as failed from email engine and write back to email client
	    if (statusMessage == "failed"){
		
		out.writeObject("Request failed, email not processed!");
		//Send user a failed message
		String name00 = null;
		String message00 = String.format("Send mail request failed!", name00);
		JOptionPane.showMessageDialog(null, message00);
		done = false;
	
	    // evaluate status message as succeeded from email engine and write back to email client	
	    } else if (statusMessage == "succeeded"){
		
		out.writeObject("Request succeeded, email processed!");
		//Send user a success message
		String name01 = null;
		String message01 = String.format("Send mail request succeeded!", name01);
		JOptionPane.showMessageDialog(null, message01);
		done = true;
	    }
	
	
        } //end while

      incoming.close();

      //Put this thread to sleep for 50000ms
      Thread.sleep(50000);

      System.out.println("Thread " + counter + " ending");
      } catch (Exception e){

      System.out.println(e);

      }// end try/catch

   } // end of run method

static Logger log = Logger.getLogger("com.pedigrees");

public String getEngineStarted(){
	
	
	// Validation Strings for Envelope Name Checks
     String sendersFirstNameCheck;
     String receiversFirstNameCheck;
     
     //Database Connection Strings
     String str1;
     String str2;
     String str3;
                       
      //Sentinel Variable for do/while loop
      int status = 1;
      //do/while loop database processing
      do{
          Envelope e1 = new Envelope();

        //start of Connecting to the Database try/catch block
    	try
	    {
		             //loading the JDBC Driver 
	                 dBDriverLoad();
                                   
		//Getting database connection properties
		 ApplicationContext dbcontext = new ClassPathXmlApplicationContext("applicationContext.xml");
         JDBCServer jDBCServer = (JDBCServer)dbcontext.getBean("jdbcCfg");
                                            
         str1 = jDBCServer.getJDBCUrl("url");
         str2 = jDBCServer.getJDBCUser("user");
         str3 = jDBCServer.getJDBCPassword("password");
         /* for test purposes:
         System.out.println(str1);
         System.out.println(str2);
         System.out.println(str3);
	      */
                                                                                                        
         //Binding the database connection
		Connection conn = DriverManager.getConnection(str1, str2, str3);
         /* for test purpose
         System.out.println(conn);
		*/
		//Create the first DML construct
		Statement stmt1 = conn.createStatement();
		
		//Issuing first SQL statement - Selecting
		String sql1 = "SELECT * FROM SENDER";
		ResultSet rs1 = stmt1.executeQuery(sql1);
	
		// Use inner while loop copying data from the epedigree Sender table into the Envelope-Receiver object fields
		while (rs1.next())
		{
			
	        e1.setEnvelopeSendersFirstName(rs1.getString(1));
			e1.setEnvelopeSendersMiddleInitial(rs1.getString(2));
			e1.setEnvelopeSendersLastName(rs1.getString(3));
			e1.setEnvelopeSendersStreetAddress(rs1.getString(4));
			e1.setEnvelopeSendersCity(rs1.getString(5));
			e1.setEnvelopeSendersState(rs1.getString(6));
			e1.setEnvelopeSendersZipCode(rs1.getString(7));
			e1.setEnvelopeMessageBody(rs1.getString(8));
			
	    }
	
		//Close the first DML construct
		stmt1.close();
		
		//Create the second DML construct
		Statement stmt2 = conn.createStatement();
		
		//Issuing second SQL statement - Selecting
		String sql2 = "SELECT * FROM RECEIVER";
		ResultSet rs2 = stmt2.executeQuery(sql2);
	
		//Use another inner while loop copying data from the epedigree Receiver table into the Envelope-Sender object fields
		while (rs2.next())
		{
			
			e1.setEnvelopeReceiversFirstName(rs2.getString(1));
			e1.setEnvelopeReceiversMiddleInitial(rs2.getString(2));
			e1.setEnvelopeReceiversLastName(rs2.getString(3));
			e1.setEnvelopeReceiversStreetAddress(rs2.getString(4));
			e1.setEnvelopeReceiversCity(rs2.getString(5));
			e1.setEnvelopeReceiversState(rs2.getString(6));
			e1.setEnvelopeReceiversZipCode(rs2.getString(7));
			
	    }
	
		//Close the second DML construct
		stmt2.close();
		
		
		//Disconnect from the database
		conn.close();
	 	
	} catch (Exception ex) {
		log.debug("database connection problem!");
	} // end of Connecting to the Database try/catch block 
	
      //testing envelope
      receiversFirstNameCheck = e1.getEnvelopeReceiversFirstName();
      sendersFirstNameCheck = e1.getEnvelopeSendersFirstName();
      if (sendersFirstNameCheck != null && receiversFirstNameCheck != null ){
    	  log.info("Sender's and Receiver's First Name Checks are valid");
    	  log.info("Sender's First name should be:   " + sendersFirstNameCheck);
    	  log.info("Receiver's First name should be:   " + receiversFirstNameCheck);
	  status = 0;
	 
     } else {
	  log.debug("Sender First Name Check is not valid");
   	 status = -1;
  } // end of Sender First Name Check Testing

  //     
  } while (status == 1);

   // Send bad status message to email client
    if (status == -1){
    	log.debug("email request could not be processed by email server!");
    engineState = "failed";
	    

    // Send good status message back to email client
    } else if (status == 0){
     log.info("email request was processed by email server!");
     engineState = "succeeded";

     } // end of status message condition blocks (if/else)

    return engineState; // Return engine state back to email server
    
  } // end of getEngineStarted

public void dBDriverLoad() {

	//An Attempt to load JDBC driver
        try
           {
             Class.forName("com.mysql.jdbc.Driver").newInstance();
      } catch (Exception ex)
      {
    	  log.debug("error in loading JDBC driver!");
      } // end of load JDBC driver try/block
	
   } // End of dBDriverLoad

} // end of ThreadedEmailServer