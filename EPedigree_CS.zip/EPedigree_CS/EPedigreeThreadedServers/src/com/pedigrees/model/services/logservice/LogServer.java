package com.pedigrees.model.services.logservice;

public class LogServer {

	private String propFileLocation;
	
	
	public void setPropFileLocation(String propFileLocation ){
		 
		 this.propFileLocation = propFileLocation;
		 	 
	 	} // end of propFileLocation
	
	public String getPropFile (String propFile){
		
		propFile = propFileLocation;
		
		return propFile;
	}
	
	
} // end of LogServer
