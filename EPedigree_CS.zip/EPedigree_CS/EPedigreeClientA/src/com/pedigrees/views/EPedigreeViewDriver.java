package com.pedigrees.views;
import com.pedigrees.views.ElectronicPedigreeJFrame;

/**
 * EPedigree View Driver is a utility to test drive the
 * ElectronicPedgireeFrame.
 * @author Ish
 *
 */

public class EPedigreeViewDriver {

	public static void main(String[] args)
	{
		EPedigreeViewDriver callingEpedigreeViewDriver = new EPedigreeViewDriver();
                                    callingEpedigreeViewDriver.view();
	} // end of main

	// calls ElectronicPedigreeFrame in view
	public void view()
	{
            	
		ElectronicPedigreeJFrame ePF = new ElectronicPedigreeJFrame();
		ePF.setSize(455, 220);
		ePF.setVisible(true);
	} // end of view
	
} // end of EPedigreeViewDriver
