package com.pedigrees.views;
import com.pedigrees.controller.EmailClient;
import java.awt.FlowLayout;
import java.awt.event.ItemListener;
import java.awt.event.ItemEvent;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JComboBox;



public class ComboBoxEmailJFrame extends JFrame {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private JComboBox viewObjects;
	private JLabel label;
	
	private static final String[] names =
	{"Select Command:", "Send Envelope", "Recieve Envelope"};
	
	public ComboBoxEmailJFrame(){
		
		super("Email");
		setLayout(new FlowLayout());
		
		viewObjects = new JComboBox(names);
		viewObjects.setMaximumRowCount(2);
		
		viewObjects.addItemListener(new ItemListener()
		{
			// handle JCombo
			public void itemStateChanged(ItemEvent e)
			{
				String item = (String)e.getItem();
				if(e.getStateChange() == ItemEvent.SELECTED)
				{
					if (item == "Send Envelope")
					{
						//start EmailClientA to send an Envelope to the Email Server
						EmailClient emailClient = new EmailClient();
						emailClient.sendMail();
						
					}  // end of "if" evaluation for Send Envelope
					
					// will be used in multi-threaded application versioin
					else if(item == "Receive Envelope")
					{
						//start EmailClientA to receive an Envelope from the Email Server
						//EmailClientA emailClientA = new EmailClientA();
						System.out.println("Featured in next code release");
						
					} // end of "if" evaluation for Receive Envelope
					
				} // end of "if" evaluation for getStateChange method 
			} // end of itemStateChanged Method
			
		}); // end of viewObjects.addItemListener method
		
		add(viewObjects);
		label = new JLabel("Option");
		add(label);

	} // end of ComboBoxEmailJFrame constructor
	

} // end of ComboBoxEmailJFrame class
