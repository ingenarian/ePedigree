package com.pedigrees.views;
import com.pedigrees.views.ComboBoxEmailJFrame;
import javax.swing.JFrame;
import javax.swing.Box;
import javax.swing.JButton;
import javax.swing.JOptionPane;
import javax.swing.JTabbedPane;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;


//import org.apache.log4j.Logger;

/**
 * Electronic Pedigree Frame is the main GUI to create pedigrees and envelopes
 * @author Ish
 * 
 */
public class ElectronicPedigreeJFrame extends JFrame
{
	/*
	 * Category set in config/log4j.properties as
	 * log4j.category.com.pedigree=DEBUG, console, File
	 */
//	static Logger log = Logger.getLogger("com.pedigrees");
	private static final long serialVersionUID = -2415035725583645224L;
	
	// Setup main GUI
	public ElectronicPedigreeJFrame()
	{
		super("E-Pedigree Application");
		
		//create Box containers with BoxLayout
		
        Box horizontal5 = Box.createHorizontalBox();
		
		
		
                // add buttons to Box horizontal5 (Admin Buttons)
		JButton label0Button = new JButton("View");
		JButton label0aButton = new JButton("Package");
		JButton label0bButton = new JButton("Email");
	 	JButton label0cButton = new JButton("Help");
	 	JButton label0dButton = new JButton("Cancel");
	 //	label0Button.addActionListener(new Label0ButtonListener());
	   // label0aButton.addActionListener(new Label0aButtonListener());
	    label0bButton.addActionListener(new Label0bButtonListener());
	//	label0cButton.addActionListener(new Label0cButtonListener());
	//	label0dButton.addActionListener(new Label0dButtonListener());
		horizontal5.add(label0Button);
	    horizontal5.add(label0aButton);
	    horizontal5.add(label0bButton);
	    horizontal5.add(label0cButton);
	    horizontal5.add(label0dButton);
            
	   // create a JTabbedPane
	   JTabbedPane tabs = new JTabbedPane(
			   JTabbedPane.TOP, JTabbedPane.SCROLL_TAB_LAYOUT);
	   
	   //place each container on tabbed pane
	   tabs.addTab("Admin", horizontal5);
	   add(tabs); // place tabbed pane on frame
	} // end BoxLayoutFrame constructor for main GUI

        // create handler for the view button on the Admin Tab
	class Label0bButtonListener implements ActionListener {
		public void actionPerformed(ActionEvent event) {
			
	//		log.debug("Entering the Email GUI from the ElectronicPedgireeJFrame");
                                                      
			
			//Send user a retrieval message
			String name00 = null;
			String message00 = 
			String.format("Retrieving email client!", name00);
			
			JOptionPane.showMessageDialog(null, message00);
			
			
			ComboBoxEmailJFrame comboBoxEmailJFrame = new ComboBoxEmailJFrame();
			comboBoxEmailJFrame.setSize(300, 100);
			comboBoxEmailJFrame.setVisible(true);
	
		} // end of actionPerformed
	}// end of Label0bButtonListener
    
} // end of ElectronicPedigreeJFrame class