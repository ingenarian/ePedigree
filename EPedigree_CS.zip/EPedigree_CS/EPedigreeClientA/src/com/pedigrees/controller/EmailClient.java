package com.pedigrees.controller;
import com.pedigrees.services.networkservice.NetworkClient;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.InetAddress;
import java.net.Socket;
import java.net.UnknownHostException;

/*
 * The EmailClient is a manager for the view.
 * It calls ApplicationContext for IoC with the NetworkClient (Interface/Implementation)
 * @author Ish
 * 
 */


public class EmailClient {

	public void sendMail(){
		
		Socket z = null;
		
		ObjectOutputStream out = null;
		ObjectInputStream is = null;


		   try
	       {
   		 // Step 1: Create Socket to make a connection
	        
			   String thisIP;
				String thisPort;
				int thisConvertedPort;
				
				ApplicationContext context = new ClassPathXmlApplicationContext(
				"applicationContext.xml");
				
				NetworkClient networkClient = (NetworkClient)context.getBean("netCfg");
				thisPort = networkClient.getPort("port");
				thisConvertedPort = Integer.parseInt(thisPort);
				thisIP = networkClient.getIP("IP");
	         z = new Socket(InetAddress.getByName(thisIP), thisConvertedPort);

	         // Step 2: Get input and output streams
	         out = new ObjectOutputStream(z.getOutputStream());
	         out.flush();
	         out.writeObject("Client >> I have mail to send!");
	         is = new ObjectInputStream(z.getInputStream());

	         // Step 3: Process connection
	         String str = (String)is.readObject(); // get what server has to say
	         System.out.println(str);

	         out.writeObject("Send Mail"); // send to server
		     out.flush();

		        // display server's message
		        String serverStr = (String)is.readObject();
		        System.out.println(serverStr);
		        
	      }
	      catch (UnknownHostException e)
	      {
	         System.err.println("Don't know about host ");
	         System.exit(1);
	      }
	      catch (IOException e)
	      {
	         System.err.println("Couldn't get I/O for ");
	         System.exit(1);
	      }
	      catch(Exception e) { System.out.println("Error" + e); }
	      finally 
	      {
	        try
	        {
	    	  // Step 4: Close connection
	    	  out.close();
		      is.close();
		  //    stdIn.close();
		      z.close();
	        }
	        catch(Exception e){}
		  } // end finally block
	      
	     
	} // end of sendMail method

} // end of EmailClient
